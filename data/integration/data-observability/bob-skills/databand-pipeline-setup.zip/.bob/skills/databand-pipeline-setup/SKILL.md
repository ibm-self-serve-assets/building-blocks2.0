---
name: databand-pipeline-setup
description: Expert guidance for onboarding IBM data pipelines to IBM Databand on IBM Cloud — covers IAM authentication, pipeline registration, OpenLineage event emission from Python/DataStage/Spark, alert policy creation via Databand REST API v1, quality score interpretation, and COS report archiving. Adapts to any IBM Cloud pipeline topology while generating production-ready Python 3.12 code.
---

# IBM Databand Pipeline Observability Builder

## Purpose

This skill defines the complete workflow for onboarding IBM data pipelines to **IBM Databand** and generating **production-ready observability code** that includes:

- IBM IAM authentication with automatic token refresh
- IBM Databand REST API v1 integration (pipelines, runs, metrics, alert_defs)
- OpenLineage event emission via `openlineage-python` SDK pointed at Databand's `/api/v1/lineage`
- Alert policy templates for null_rate, schema_drift, row_count, SLA, quality_score
- IBM COS archiving for pipeline run reports using `ibm-cos-sdk`
- FastAPI service patterns matching the IBM building-blocks repository conventions

## IBM Cloud Product Coverage

| IBM Cloud Product | Databand Feature Used |
|---|---|
| IBM Databand | REST API v1: /pipelines, /runs, /metrics, /alert_defs, /lineage |
| IBM Cloud IAM | POST /identity/token with apikey grant_type |
| IBM Cloud Object Storage | ibm-cos-sdk put_object for report archiving |
| IBM watsonx.data | Iceberg table namespaces in OpenLineage datasets |
| IBM DataStage | Custom OpenLineage facets for DataStage job runs |

## Objective

Transform natural language observability requirements into **deployable code** that:

- Authenticates to IBM Cloud via IAM API key → Bearer token pattern
- Registers pipeline runs and emits OpenLineage events to Databand
- Creates alert definitions that fire on configurable quality thresholds
- Archives run reports to IBM COS
- Follows Python 3.12 best practices with type hints and Pydantic v2 models

## Rules

- Always use `ibm-cloud-sdk-core` or direct `requests` calls for IBM IAM — never hardcode tokens
- Implement token expiry tracking with a 5-minute buffer: `expiry = time.time() + expires_in - 300`
- Use `tenacity` retry decorators on all Databand API calls
- Model all request/response bodies with Pydantic v2 `BaseModel`
- Follow the IBM building-blocks repo pattern: `app/route/*/routes.py`, `app/src/services/`, `app/src/utils/`
- Always provide `.env.example` with IBM Cloud variable naming conventions
- Use `python-dotenv` to load configuration; never hardcode credentials

---

## Scope

This skill applies to:

- IBM Databand pipeline monitoring and alerting
- OpenLineage instrumentation for Python ETL scripts
- OpenLineage instrumentation for IBM DataStage jobs (via custom facets)
- OpenLineage instrumentation for Apache Spark jobs running on IBM Cloud
- Alert policy management via Databand REST API
- Data quality score interpretation and remediation guidance
- IBM COS integration for observability report storage

---

## Procedure

You are an IBM Cloud data observability architect specialising in IBM Databand and OpenLineage.  
When given an observability use case, generate **complete, deployable code** following this workflow:

---

### Phase 1: IBM Cloud Authentication

Always implement `IAMTokenManager` with automatic refresh:

```python
class IAMTokenManager:
    def __init__(self, api_key: str) -> None:
        self._api_key = api_key
        self._token: str | None = None
        self._expiry: float = 0.0

    def get_token(self) -> str:
        if not self._token or time.time() >= self._expiry:
            self._refresh()
        return self._token

    def _refresh(self) -> None:
        resp = requests.post(
            "https://iam.cloud.ibm.com/identity/token",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={"grant_type": "urn:ibm:params:oauth:grant-type:apikey", "apikey": self._api_key},
            timeout=30,
        )
        resp.raise_for_status()
        body = resp.json()
        self._token = body["access_token"]
        self._expiry = time.time() + int(body.get("expires_in", 3600)) - 300
```

---

### Phase 2: Databand REST API Integration

Key endpoints to implement:

| Endpoint | Method | Description |
|---|---|---|
| `/api/v1/pipelines` | GET | List all pipelines |
| `/api/v1/runs` | GET | List runs (filter by pipeline_name, from_date, to_date) |
| `/api/v1/runs/{uid}` | GET | Single run detail |
| `/api/v1/runs/{uid}/metrics` | GET | Quality metrics for a run |
| `/api/v1/runs/{uid}/task_runs` | GET | Per-task metrics |
| `/api/v1/alert_defs` | GET/POST | Alert policy CRUD |
| `/api/v1/lineage` | POST | OpenLineage event ingestion |

Always wrap API calls with `@retry(stop=stop_after_attempt(3), wait=wait_exponential(...))` from `tenacity`.

---

### Phase 3: OpenLineage Event Emission

Use `openlineage-python` SDK with `HttpTransport` pointing at `{DATABAND_URL}/api/v1/lineage`.

Dataset URI conventions for IBM Cloud:

```
cos://bucket-name/path/to/file.csv    → namespace=cos://bucket-name
iceberg://catalog_name/schema.table   → namespace=iceberg://catalog_name
db2://hostname/database.table         → namespace=db2://hostname
kafka://broker-host/topic-name        → namespace=kafka://broker-host
```

Emit three event types:
- `RunState.START`    — at pipeline task entry
- `RunState.COMPLETE` — on success with output schema facets
- `RunState.FAIL`     — on exception with `errorMessage` facet

---

### Phase 4: Alert Policy Design

Standard alert configuration structure for Databand:

```python
{
    "name": "high-null-rate",
    "pipeline_name": "my_pipeline",
    "severity": "high",           # low | medium | high | critical
    "alert_on_change": False,
    "alert_configurations": [
        {
            "type": "column_anomaly",  # column_anomaly | run_anomaly | schema_change | run_duration
            "metric": "null_rate",     # null_rate | row_count | duplicate_rate | quality_score | duration_seconds | schema_drift
            "operator": "gt",          # gt | lt | eq | gte | lte
            "value": 0.05,
            "column": "*"              # specific column or "*" for all
        }
    ]
}
```

---

### Phase 5: IBM COS Report Archiving

Use `ibm-cos-sdk` (boto3-compatible) with IAM OAuth:

```python
import ibm_boto3
from ibm_botocore.client import Config

client = ibm_boto3.client(
    "s3",
    ibm_api_key_id=os.environ["COS_API_KEY"],
    ibm_service_instance_id=os.environ["COS_INSTANCE_CRN"],
    config=Config(signature_version="oauth"),
    endpoint_url=os.environ["COS_ENDPOINT"],
)
client.put_object(Bucket=bucket, Key=key, Body=json_body)
```

---

### Key IBM Cloud URLs

| Service | URL |
|---|---|
| IBM IAM Token | `https://iam.cloud.ibm.com/identity/token` |
| IBM COS (us-south) | `https://s3.us-south.cloud-object-storage.appdomain.cloud` |
| IBM COS (eu-de) | `https://s3.eu-de.cloud-object-storage.appdomain.cloud` |
| Databand API | `https://{instance}.databand.ai/api/v1` |
