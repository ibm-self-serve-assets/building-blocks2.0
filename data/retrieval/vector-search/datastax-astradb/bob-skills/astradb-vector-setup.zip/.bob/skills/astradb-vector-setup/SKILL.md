---
name: astradb-vector-setup
description: Expert guidance for DataStax Astra DB vector collections on IBM Cloud (HCD portfolio) — covers astrapy Data API, IBM watsonx.ai embedding integration, collection creation with cosine metric, bulk insert with $vector field, ANN search queries, and IBM COS document source. Generates production-ready Python 3.12 FastAPI services.
---

# DataStax Astra DB Vector Search Builder

## Purpose

Expert guidance for building vector search applications with **DataStax Astra DB** — part of the IBM Cloud HCD (Hyper-Converged Database) portfolio. Generates Python 3.12 FastAPI services using `astrapy` SDK with **IBM watsonx.ai** embeddings and **IBM COS** as document source.

## IBM Cloud Product Coverage

| IBM Cloud Product | Usage |
|---|---|
| IBM HCD / DataStax Astra DB | Vector collection creation, insert, ANN search |
| IBM watsonx.ai | Embedding generation: ibm/slate-125m-english-rtrvr |
| IBM Cloud Object Storage | Document source with ibm-cos-sdk |
| IBM Cloud IAM | API key → Bearer token for watsonx.ai |

## Rules

- Use `astrapy>=1.5.2` Data API client — NOT the deprecated `astrapy.db.AstraDB`
- `ASTRA_DB_API_ENDPOINT` format: `https://{DB_ID}-{REGION}.apps.astra.datastax.com`
- `ASTRA_DB_APPLICATION_TOKEN` format: `AstraCS:...`
- Vector field in Astra DB documents: `$vector` (not `vector`)
- Document `_id` field: must be unique string — use SHA-256 hash of content
- Batch insert: use `collection.insert_many()` with batches of ≤ 20 documents
- ANN search: use `collection.find()` with `sort={"$vector": query_vector}`

---

## Procedure

### Phase 1: Astra DB Connection

```python
from astrapy import DataAPIClient
from astrapy.constants import VectorMetric

client = DataAPIClient(token=ASTRA_DB_APPLICATION_TOKEN)
db = client.get_database(ASTRA_DB_API_ENDPOINT)
```

### Phase 2: Create Vector Collection

```python
collection = db.create_collection(
    "ibm_docs_vectors",
    dimension=768,                   # must match embedding model dim
    metric=VectorMetric.COSINE,
)
```

### Phase 3: Insert Documents with Vectors

```python
records = [
    {
        "_id": doc_id_hash,      # unique string ID
        "$vector": [0.1, 0.2, ...],  # embedding vector
        "text": chunk_text,
        "title": filename,
        "source": cos_key,
    }
    for doc, vec in zip(batch, vectors)
]
collection.insert_many(records, ordered=False)
```

### Phase 4: ANN Vector Search

```python
query_vector = embedder.embed_query(user_question)

results = collection.find(
    {},
    sort={"$vector": query_vector},
    limit=10,
    projection={"text": True, "title": True, "source": True, "$similarity": True},
)

for doc in results:
    print(doc["text"], doc.get("$similarity"))
```

### Phase 5: IBM watsonx.ai Embeddings

```python
from ibm_watsonx_ai import Credentials
from ibm_watsonx_ai.foundation_models import Embeddings

embedder = Embeddings(
    model_id="ibm/slate-125m-english-rtrvr",   # dim=768
    credentials=Credentials(url="https://us-south.ml.cloud.ibm.com", api_key=IBM_API_KEY),
    project_id=WATSONX_PROJECT_ID,
)
```

### Embedding Model Dimensions

| Model ID | Dimension |
|---|---|
| `ibm/slate-125m-english-rtrvr` | 768 |
| `ibm/slate-30m-english-rtrvr` | 384 |
| `intfloat/multilingual-e5-large` | 1024 |

### Key IBM Cloud URLs

| Service | URL |
|---|---|
| IBM IAM Token | `https://iam.cloud.ibm.com/identity/token` |
| IBM watsonx.ai (us-south) | `https://us-south.ml.cloud.ibm.com` |
| IBM COS (us-south) | `https://s3.us-south.cloud-object-storage.appdomain.cloud` |
| Astra DB API | `https://{DB_ID}-{REGION}.apps.astra.datastax.com` |
