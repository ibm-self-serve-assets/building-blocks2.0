---
name: openlineage-instrumentation
description: Expert guidance for instrumenting IBM data pipelines (Python ETL, IBM DataStage, Apache Spark) with OpenLineage, forwarding events to IBM Databand, and querying the Manta data lineage graph via watsonx.data Intelligence REST API. Generates production-ready Python 3.12 code with IAM auth, dataset URI conventions, and COS report archiving.
---

# IBM Data Lineage Instrumentation Builder

## Purpose

This skill defines the complete workflow for instrumenting IBM data pipelines with **OpenLineage** and connecting them to **IBM watsonx.data Intelligence** (Manta lineage) and **IBM Databand** for lineage tracking. Generates deployable Python 3.12 code following IBM building-blocks conventions.

## IBM Cloud Product Coverage

| IBM Cloud Product | Usage |
|---|---|
| watsonx.data Intelligence (Manta) | REST API: /data_lineage/graphs, /data_lineage/assets, /data_lineage/impact_analysis |
| IBM Databand | OpenLineage ingest: /api/v1/lineage (Marquez-compatible) |
| IBM Cloud IAM | POST /identity/token (apikey grant) |
| IBM Cloud Object Storage | Lineage report archiving with ibm-cos-sdk |
| IBM DataStage | Custom OpenLineage job facets |
| Apache Spark on IBM Cloud | SparkListener-based OpenLineage emission |

## Objective

Transform natural language lineage requirements into **deployable instrumentation code** that:

- Emits OpenLineage events (START / COMPLETE / FAIL) with correct dataset namespaces
- Forwards events to IBM Databand's Marquez endpoint
- Queries Manta lineage graphs via watsonx.data Intelligence
- Performs column-level impact analysis
- Follows Python 3.12 best practices

## Rules

- Always use `IAMTokenManager` with 5-minute token refresh buffer
- Wrap all IBM API calls with `@retry(stop=stop_after_attempt(3), ...)` from `tenacity`
- Use OpenLineage dataset URI conventions for IBM Cloud assets (see below)
- Prefer the `openlineage-python` SDK `HttpTransport` over raw requests for event emission
- Model all request/response bodies with Pydantic v2 `BaseModel`
- Provide `.env.example` with full IBM Cloud variable naming

---

## Scope

- Python ETL script instrumentation with `PipelineRun` context manager
- IBM DataStage job lineage via custom facets
- Apache Spark job lineage via openlineage-spark integration
- Manta lineage graph queries (upstream / downstream / both)
- Column-level downstream impact analysis
- OpenLineage event forwarding to IBM Databand

---

## Procedure

### Phase 1: Dataset URI Conventions for IBM Cloud

Always parse URIs to extract `namespace` and `name` for OpenLineage datasets:

| URI Pattern | Namespace | Name | IBM Asset |
|---|---|---|---|
| `cos://bucket/path/to/file.csv` | `cos://bucket` | `path/to/file.csv` | IBM COS |
| `iceberg://catalog/schema.table` | `iceberg://catalog` | `schema.table` | watsonx.data Iceberg |
| `db2://hostname/database.table` | `db2://hostname` | `database.table` | IBM Db2 |
| `kafka://broker/topic` | `kafka://broker` | `topic` | Confluent/IBM MQ Kafka |
| `datastage://project/job.stage` | `datastage://project` | `job.stage` | IBM DataStage |

### Phase 2: OpenLineage Event Structure

```python
event = RunEvent(
    eventType=RunState.COMPLETE,
    eventTime=datetime.now(timezone.utc).isoformat(),
    run=Run(runId=run_id),
    job=Job(
        namespace=pipeline_name,
        name=job_name,
        facets={
            "jobType": job_type_job.JobTypeJobFacet(
                processingType="BATCH",
                integration="PYTHON",
                jobType="JOB",
            )
        },
    ),
    inputs=[Dataset(namespace="cos://raw-bucket", name="orders.csv")],
    outputs=[
        Dataset(
            namespace="iceberg://cos_catalog",
            name="sales.orders",
            facets={
                "schema": SchemaDatasetFacet(fields=[
                    SchemaDatasetFacetFields(name="order_id", type="string"),
                    SchemaDatasetFacetFields(name="amount",   type="double"),
                ])
            },
        )
    ],
    producer="https://github.com/IBM/building-blocks",
)
```

### Phase 3: IBM Databand Marquez Endpoint

```python
from openlineage.client import OpenLineageClient
from openlineage.client.transport.http import HttpConfig, HttpTransport

client = OpenLineageClient(
    transport=HttpTransport(
        HttpConfig(
            url=f"{DATABAND_URL}/api/v1/lineage",
            auth={"type": "bearer", "token": access_token},
            verify=True,
            timeout=30,
        )
    )
)
client.emit(event)
```

### Phase 4: Manta Lineage Graph Queries

| Endpoint | Method | Description |
|---|---|---|
| `/data_lineage/graphs` | GET | Lineage graph (params: asset_id, direction, depth) |
| `/data_lineage/assets` | GET | All lineage-tracked assets |
| `/data_lineage/impact_analysis` | GET | Downstream assets affected by source change |

All endpoints: `?project_id={WXDI_PROJECT_ID}` required.

### Phase 5: Impact Analysis Pattern

```python
# Step 1: Get downstream impact
impact = requests.get(
    f"{WXDI_BASE}/data_lineage/impact_analysis",
    headers={"Authorization": f"Bearer {token}"},
    params={"project_id": project_id, "asset_id": asset_id},
).json()

# Step 2: Render dependency tree
for node in impact.get("downstream_assets", []):
    print(f"  └── {node['name']} [{node.get('asset_type', '')}]")
```

### Key IBM Cloud URLs

| Service | URL |
|---|---|
| IBM IAM Token | `https://iam.cloud.ibm.com/identity/token` |
| watsonx.data Intelligence (us-south) | `https://api.us-south.dai.cloud.ibm.com` |
| IBM Databand lineage endpoint | `https://{instance}.databand.ai/api/v1/lineage` |
| IBM COS (us-south) | `https://s3.us-south.cloud-object-storage.appdomain.cloud` |
