#!/usr/bin/env python3
"""
Business Logic Analyzer Module
Analyzes Java code to extract and preserve business logic during conversion
"""

import re
from typing import Any, Dict, List, Set


class BusinessLogicAnalyzer:
    """Analyzes Java code to identify and preserve business logic"""

    def __init__(self):
        """Initialize analyzer"""
        self.business_patterns = {
            'validations': [
                r'if\s*\([^)]*>\s*\d+',
                r'if\s*\([^)]*<\s*\d+',
                r'if\s*\([^)]*==\s*["\']',
                r'\.equals\(',
                r'throw\s+new\s+MXApplicationException'
            ],
            'database_operations': [
                r'\.getMboSet\(',
                r'\.getMbo\(',
                r'\.getString\(',
                r'\.getDouble\(',
                r'\.getInt\(',
                r'\.setValue\(',
                r'\.count\(\)',
                r'\.close\(\)'
            ],
            'business_rules': [
                r'if\s*\([^)]*status',
                r'if\s*\([^)]*priority',
                r'if\s*\([^)]*cost',
                r'if\s*\([^)]*date'
            ]
        }

    def analyze(self, java_source: str) -> Dict:
        """
        Analyze Java source code for business logic

        Args:
            java_source: Java source code string

        Returns:
            Dictionary containing analysis results
        """
        analysis = {
            'method_count': self._count_methods(java_source),
            'validation_count': self._count_validations(java_source),
            'db_operation_count': self._count_db_operations(java_source),
            'business_rules': self._extract_business_rules(java_source),
            'critical_logic': self._identify_critical_logic(java_source),
            'data_flow': self._analyze_data_flow(java_source),
            'dependencies': self._extract_dependencies(java_source)
        }

        return analysis

    def _count_methods(self, source: str) -> int:
        """Count number of methods in source"""
        pattern = r'(public|private|protected)\s+\w+\s+\w+\s*\([^)]*\)'
        return len(re.findall(pattern, source))

    def _count_validations(self, source: str) -> int:
        """Count validation logic instances"""
        count = 0
        for pattern in self.business_patterns['validations']:
            count += len(re.findall(pattern, source, re.IGNORECASE))
        return count

    def _count_db_operations(self, source: str) -> int:
        """Count database operation instances"""
        count = 0
        for pattern in self.business_patterns['database_operations']:
            count += len(re.findall(pattern, source))
        return count

    def _extract_business_rules(self, source: str) -> List[Dict]:
        """Extract business rules from source"""
        rules = []

        if_pattern = r'if\s*\(([^)]+)\)\s*\{([^}]+)\}'
        for match in re.finditer(if_pattern, source, re.DOTALL):
            condition = match.group(1).strip()
            action = match.group(2).strip()

            if self._is_business_rule(condition):
                rules.append({
                    'condition': condition,
                    'action': action,
                    'type': self._classify_rule(condition)
                })

        return rules

    def _is_business_rule(self, condition: str) -> bool:
        """Check if condition represents a business rule"""
        business_keywords = [
            'status', 'priority', 'cost', 'date', 'amount',
            'limit', 'threshold', 'approved', 'valid'
        ]
        return any(keyword in condition.lower() for keyword in business_keywords)

    def _classify_rule(self, condition: str) -> str:
        """Classify the type of business rule"""
        condition_lower = condition.lower()

        if 'status' in condition_lower:
            return 'status_validation'
        if 'cost' in condition_lower or 'amount' in condition_lower:
            return 'financial_validation'
        if 'date' in condition_lower:
            return 'temporal_validation'
        if 'priority' in condition_lower:
            return 'priority_check'
        return 'general_validation'

    def _identify_critical_logic(self, source: str) -> List[str]:
        """Identify critical business logic that must be preserved"""
        critical = []

        exceptions = re.findall(
            r'throw\s+new\s+MXApplicationException\([^)]+\)',
            source
        )
        critical.extend(exceptions)

        modifications = re.findall(
            r'\.setValue\([^)]+\)',
            source
        )
        critical.extend(modifications)

        status_changes = re.findall(
            r'\.setValue\(["\']STATUS["\'][^)]+\)',
            source,
            re.IGNORECASE
        )
        critical.extend(status_changes)

        return critical

    def _analyze_data_flow(self, source: str) -> Dict:
        """Analyze data flow through the code"""
        flow = {
            'inputs': self._extract_inputs(source),
            'outputs': self._extract_outputs(source),
            'transformations': self._extract_transformations(source)
        }
        return flow

    def _extract_inputs(self, source: str) -> List[str]:
        """Extract input data sources"""
        inputs = []

        param_pattern = r'\w+\s+\w+\s*\(([^)]+)\)'
        for match in re.finditer(param_pattern, source):
            params = match.group(1)
            if params.strip():
                inputs.extend([p.strip() for p in params.split(',')])

        reads = re.findall(r'\.getString\(["\'](\w+)["\']\)', source)
        reads.extend(re.findall(r'\.getDouble\(["\'](\w+)["\']\)', source))
        inputs.extend(reads)

        return list(set(inputs))

    def _extract_outputs(self, source: str) -> List[str]:
        """Extract output data destinations"""
        outputs = []

        writes = re.findall(r'\.setValue\(["\'](\w+)["\']', source)
        outputs.extend(writes)

        returns = re.findall(r'return\s+([^;]+);', source)
        outputs.extend(returns)

        return list(set(outputs))

    def _extract_transformations(self, source: str) -> List[str]:
        """Extract data transformations"""
        transformations = []

        calcs = re.findall(r'(\w+)\s*[+\-*/]=\s*([^;]+);', source)
        transformations.extend([f"{calc[0]} = {calc[1]}" for calc in calcs])

        assigns = re.findall(r'(\w+)\s*=\s*([^;]+[+\-*/][^;]+);', source)
        transformations.extend([f"{assign[0]} = {assign[1]}" for assign in assigns])

        return transformations

    def _extract_dependencies(self, source: str) -> Dict:
        """Extract code dependencies"""
        dependencies = {
            'maximo_classes': self._extract_maximo_classes(source),
            'java_classes': self._extract_java_classes(source),
            'custom_classes': self._extract_custom_classes(source)
        }
        return dependencies

    def _extract_maximo_classes(self, source: str) -> Set[str]:
        """Extract Maximo-specific class dependencies"""
        maximo_classes = set()

        imports = re.findall(r'import\s+psdi\.([^;]+);', source)
        maximo_classes.update(imports)

        usage = re.findall(r'(Mbo\w+|MX\w+)', source)
        maximo_classes.update(usage)

        return maximo_classes

    def _extract_java_classes(self, source: str) -> Set[str]:
        """Extract Java standard library dependencies"""
        java_classes = set()

        imports = re.findall(r'import\s+java\.([^;]+);', source)
        java_classes.update(imports)

        return java_classes

    def _extract_custom_classes(self, source: str) -> Set[str]:
        """Extract custom class dependencies"""
        custom_classes = set()

        imports = re.findall(r'import\s+(?!psdi|java)([^;]+);', source)
        custom_classes.update(imports)

        return custom_classes

    def validate_preservation(self, original_java: str, converted_script: str) -> Dict[str, Any]:
        """
        Validate that business logic is preserved in conversion

        Args:
            original_java: Original Java source
            converted_script: Converted automation script

        Returns:
            Validation results dictionary
        """
        original_analysis = self.analyze(original_java)

        validation_flags = {
            'validations_preserved': self._check_validations_preserved(
                original_analysis, converted_script
            ),
            'db_operations_preserved': self._check_db_operations_preserved(
                original_analysis, converted_script
            ),
            'business_rules_preserved': self._check_business_rules_preserved(
                original_analysis, converted_script
            ),
            'critical_logic_preserved': self._check_critical_logic_preserved(
                original_analysis, converted_script
            )
        }

        validation: Dict[str, Any] = dict(validation_flags)
        validation['overall_score'] = self._calculate_preservation_score(validation_flags)

        return validation

    def _check_validations_preserved(self, analysis: Dict, script: str) -> bool:
        """Check if validations are preserved"""
        validation_patterns = [
            r'if\s+.*[><]=?\s*\d+',
            r'if\s+.*==\s*["\']',
            r'raise\s+MXApplicationException'
        ]

        found_validations = sum(
            len(re.findall(pattern, script, re.IGNORECASE))
            for pattern in validation_patterns
        )

        expected = analysis['validation_count']
        return found_validations >= expected * 0.8

    def _check_db_operations_preserved(self, analysis: Dict, script: str) -> bool:
        """Check if database operations are preserved"""
        db_patterns = [
            r'\.getMboSet\(',
            r'\.getString\(',
            r'\.getDouble\(',
            r'\.setValue\('
        ]

        found_operations = sum(
            len(re.findall(pattern, script))
            for pattern in db_patterns
        )

        expected = analysis['db_operation_count']
        return found_operations >= expected * 0.8

    def _check_business_rules_preserved(self, analysis: Dict, script: str) -> bool:
        """Check if business rules are preserved"""
        rules = analysis['business_rules']
        preserved_count = 0

        for rule in rules:
            condition_keywords = re.findall(r'\w+', rule['condition'])
            if all(keyword in script for keyword in condition_keywords[:3]):
                preserved_count += 1

        return preserved_count >= len(rules) * 0.8 if rules else True

    def _check_critical_logic_preserved(self, analysis: Dict, script: str) -> bool:
        """Check if critical logic is preserved"""
        critical = analysis['critical_logic']

        if not critical:
            return True

        preserved_count = 0
        for logic in critical:
            keywords = re.findall(r'\w+', logic)
            if any(keyword in script for keyword in keywords):
                preserved_count += 1

        return preserved_count >= len(critical) * 0.9

    def _calculate_preservation_score(self, validation: Dict) -> float:
        """Calculate overall preservation score"""
        scores = [
            1.0 if validation['validations_preserved'] else 0.0,
            1.0 if validation['db_operations_preserved'] else 0.0,
            1.0 if validation['business_rules_preserved'] else 0.0,
            1.0 if validation['critical_logic_preserved'] else 0.0
        ]
        return sum(scores) / len(scores) * 100


__all__ = ['BusinessLogicAnalyzer']

# Made with Bob
