# Java Conversion Workflow

## Phase 1: Prepare Runtime Folders

Ensure the converter can create or use:

- [`java-input/`](Bob_skill_Maximo_Java_Conversion/java-input)
- [`output-script/`](Bob_skill_Maximo_Java_Conversion/output-script)
- [`conversion-reports/`](Bob_skill_Maximo_Java_Conversion/conversion-reports)

## Phase 2: Discover Java Files

- Look for `.java` files in [`java-input/`](Bob_skill_Maximo_Java_Conversion/java-input)
- Prefer user-provided files
- If no files exist, instruct the user to add them first

## Phase 3: Prompt for Language

If the user did not specify a target language, prompt for one of:

- `python`
- `jython`
- `javascript`
- `nashorn`
- `ecmascript`
- `mbr`

## Phase 4: Convert

For each Java file:

1. analyze Java structure
2. extract business logic
3. generate target-language output
4. apply Maximo best practices
5. validate mandatory rules
6. save script and report

## Phase 5: Review Results

Review:
- generated script in [`output-script/`](Bob_skill_Maximo_Java_Conversion/output-script)
- validation report in [`conversion-reports/`](Bob_skill_Maximo_Java_Conversion/conversion-reports)

## Mandatory Checks

Every conversion must verify:

1. business logic retained
2. target language syntax strategy valid
3. Maximo best practices applied