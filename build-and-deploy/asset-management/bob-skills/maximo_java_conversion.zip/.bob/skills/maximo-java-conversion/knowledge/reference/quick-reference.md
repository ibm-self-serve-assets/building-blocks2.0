# Quick Reference

## Supported Input

- Java source files placed in [`java-input/`](Bob_skill_Maximo_Java_Conversion/java-input)

## Supported Output Languages

- `python`
- `jython`
- `javascript`
- `nashorn`
- `ecmascript`
- `mbr`

## Runtime Folders

The skill should create and use:

- [`java-input/`](Bob_skill_Maximo_Java_Conversion/java-input)
- [`output-script/`](Bob_skill_Maximo_Java_Conversion/output-script)
- [`conversion-reports/`](Bob_skill_Maximo_Java_Conversion/conversion-reports)

## Core Rules

1. Preserve original Java business logic
2. Generate valid syntax for the selected target language
3. Apply Maximo coding standards and best practices

## Typical Command

Run the converter from [`tools/java_to_script_converter.py`](Bob_skill_Maximo_Java_Conversion/tools/java_to_script_converter.py) or the Bob skill wrapper in [`tools/`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/tools).

## Output Expectations

- Converted scripts are written under [`output-script/`](Bob_skill_Maximo_Java_Conversion/output-script)
- Reports are written under [`conversion-reports/`](Bob_skill_Maximo_Java_Conversion/conversion-reports)

## Validation Focus

Every conversion should confirm:

- business logic retention
- language-specific syntax strategy
- Maximo best-practice coverage