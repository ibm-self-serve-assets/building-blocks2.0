# Knowledge Base Index

## Core Concepts

### Java Conversion Fundamentals
**File**: [`core/java-conversion-fundamentals.md`](core/java-conversion-fundamentals.md)
- Purpose and core principles of Java to automation script conversion
- Business logic preservation requirements
- Target language respect and Maximo best practices
- Supported Java patterns and validation model

### Language Mapping Guide
**File**: [`core/language-mapping-guide.md`](core/language-mapping-guide.md)
- Python/Jython conversion strategies
- JavaScript/Nashorn/ECMAScript conversion patterns
- MBR (Maximo Business Rules) conversion approach
- Language-specific validation expectations

### Maximo Scripting Fundamentals
**File**: [`core/maximo-scripting-fundamentals.md`](core/maximo-scripting-fundamentals.md)
- Maximo automation script types (Object, Attribute, Action, Escalation, Custom Condition)
- Core Maximo APIs (MBO, MboSet, MXServer, MXLoggerFactory)
- Script variables and execution context
- Best practices and common patterns
- Performance considerations and security guidelines

### Performance Optimization
**File**: [`core/performance-optimization.md`](core/performance-optimization.md)
- Database query optimization techniques
- Resource management and memory leak prevention
- Loop optimization and caching strategies
- Performance anti-patterns to avoid
- Performance testing and monitoring

### Security Best Practices
**File**: [`core/security-best-practices.md`](core/security-best-practices.md)
- SQL injection prevention patterns
- Input validation and sanitization
- Access control verification
- Sensitive data protection
- Error message security
- Security testing guidelines

## Procedures

### Java Conversion Workflow
**File**: [`procedures/java-conversion-workflow.md`](procedures/java-conversion-workflow.md)
- Step-by-step conversion process
- Input discovery and language selection
- Conversion execution and validation
- Report generation workflow

## Reference Materials

### Quick Reference
**File**: [`reference/quick-reference.md`](reference/quick-reference.md)
- Supported input/output languages
- Runtime folder structure
- Core conversion rules
- Command usage and output expectations

### Maximo Best Practices Reference
**File**: [`reference/maximo-best-practices-reference.md`](reference/maximo-best-practices-reference.md)
- Common patterns (secure WHERE clauses, MboSet lifecycle, error handling)
- Maximo API quick reference (MBO, MboSet, MXServer methods)
- Security patterns (SQL injection prevention, input validation)
- Performance patterns (efficient queries, batch operations, caching)
- Common anti-patterns to avoid
- Testing checklists and performance metrics

## Troubleshooting

### Common Issues
**File**: [`troubleshooting/common-issues.md`](troubleshooting/common-issues.md)
- Conversion errors and solutions
- Language-specific issues
- Business logic preservation challenges
- Validation failures and remediation

## Examples

### Java Conversion Example
**File**: [`examples/java-conversion-example.md`](examples/java-conversion-example.md)
- Complete end-to-end conversion example
- Input Java class analysis
- Generated automation script
- Validation report

## Tools

### Business Logic Analyzer
**File**: [`tools/business_logic_analyzer.py`](tools/business_logic_analyzer.py)
- Analyzes Java source code for business logic patterns
- Identifies validation rules, field updates, status transitions
- Extracts MBO/MboSet usage patterns

### Maximo Best Practices Validator
**File**: [`tools/maximo_best_practices.py`](tools/maximo_best_practices.py)
- Applies Maximo coding standards to converted scripts
- Validates security (SQL injection, input validation)
- Checks resource management (MboSet closure)
- Verifies error handling and logging
- Ensures null safety and performance optimization
- Provides comprehensive validation reports

## Knowledge Organization

### By Topic

**Conversion Process**
- Java Conversion Fundamentals
- Language Mapping Guide
- Java Conversion Workflow

**Maximo Expertise**
- Maximo Scripting Fundamentals
- Performance Optimization
- Security Best Practices
- Maximo Best Practices Reference

**Quality Assurance**
- Business Logic Analyzer
- Maximo Best Practices Validator
- Common Issues
- Testing Guidelines

### By User Need

**"I want to convert Java to automation scripts"**
1. Start with [Java Conversion Fundamentals](core/java-conversion-fundamentals.md)
2. Review [Language Mapping Guide](core/language-mapping-guide.md)
3. Follow [Java Conversion Workflow](procedures/java-conversion-workflow.md)
4. Check [Quick Reference](reference/quick-reference.md)

**"I want to ensure best practices"**
1. Review [Maximo Scripting Fundamentals](core/maximo-scripting-fundamentals.md)
2. Study [Security Best Practices](core/security-best-practices.md)
3. Learn [Performance Optimization](core/performance-optimization.md)
4. Use [Maximo Best Practices Reference](reference/maximo-best-practices-reference.md)

**"I'm having conversion issues"**
1. Check [Common Issues](troubleshooting/common-issues.md)
2. Review [Java Conversion Example](examples/java-conversion-example.md)
3. Validate with [Business Logic Analyzer](tools/business_logic_analyzer.py)
4. Apply [Maximo Best Practices Validator](tools/maximo_best_practices.py)

## Version History

- **v1.1.0** - Added comprehensive Maximo best practices documentation
  - Added Maximo Scripting Fundamentals
  - Added Performance Optimization guide
  - Added Security Best Practices
  - Enhanced Maximo Best Practices Validator with validation logic
  - Added comprehensive quick reference

- **v1.0.0** - Initial release
  - Core conversion functionality
  - Basic best practices support
  - Language mapping guide
  - Conversion workflow

## Contributing

When adding new knowledge:
1. Place files in appropriate directories (core/, procedures/, reference/, troubleshooting/, examples/)
2. Update this INDEX.md with new entries
3. Cross-reference related documents
4. Include practical examples
5. Maintain consistent formatting

## Related Skills

This skill integrates knowledge from:
- **maximo-code-optimization** - Source of comprehensive Maximo best practices
- **maximo-admin** - Maximo deployment and operations knowledge
- **Maximo Code Analyzer** - Script analysis and optimization expertise