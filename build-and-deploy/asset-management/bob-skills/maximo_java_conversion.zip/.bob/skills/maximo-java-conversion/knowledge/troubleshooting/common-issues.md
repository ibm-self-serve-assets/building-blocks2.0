# Common Issues

## No Java Files Found

### Symptom
The conversion run does not process any files.

### Cause
No `.java` files are present in [`java-input/`](Bob_skill_Maximo_Java_Conversion/java-input).

### Resolution
Add one or more Java source files to [`java-input/`](Bob_skill_Maximo_Java_Conversion/java-input) and rerun the skill.

## Wrong Target Language Selected

### Symptom
The generated output is valid, but not in the expected scripting language.

### Cause
A different target language was selected during the prompt flow.

### Resolution
Rerun the conversion and choose the correct target:
- `python`
- `jython`
- `javascript`
- `nashorn`
- `ecmascript`
- `mbr`

## Business Logic Not Fully Preserved

### Symptom
The output script misses validations, status changes, or field updates from the Java source.

### Cause
The converter mapping for that Java pattern is incomplete.

### Resolution
Review and extend [`java_to_script_converter.py`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/tools/java_to_script_converter.py) so the generated script preserves the original logic path.

## Output Syntax Is Invalid

### Symptom
The generated script contains syntax errors for the selected language.

### Cause
Language-specific generation rules were not applied correctly.

### Resolution
Verify the language mapping guidance in [`language-mapping-guide.md`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/knowledge/core/language-mapping-guide.md) and update the generator accordingly.

## Maximo Best Practices Missing

### Symptom
The script works but does not follow expected Maximo automation-script standards.

### Cause
Best-practice enforcement or validation coverage is incomplete.

### Resolution
Review:
- [`java-conversion-fundamentals.md`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/knowledge/core/java-conversion-fundamentals.md)
- [`quick-reference.md`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/knowledge/reference/quick-reference.md)

Then update validation logic to enforce cleanup, null checks, and safe Maximo API usage.