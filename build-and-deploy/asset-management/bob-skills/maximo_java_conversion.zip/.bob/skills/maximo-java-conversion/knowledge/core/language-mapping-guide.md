# Language Mapping Guide

## Purpose

This guide explains how legacy Maximo Java logic is mapped into each supported automation-script language.

## Python

Use when the user wants Python-style output.

Expected characteristics:
- `def` functions
- Python exception handling
- Maximo API calls preserved
- `.py` output in [`output-script/python/`](Bob_skill_Maximo_Java_Conversion/output-script/python)

## Jython

Use when the user explicitly wants Jython-compatible automation scripts.

Expected characteristics:
- `.py` output
- Java interoperability preserved
- Maximo-compatible scripting style
- output in [`output-script/jython/`](Bob_skill_Maximo_Java_Conversion/output-script/jython)

## JavaScript

Use when the user wants JavaScript automation scripts.

Expected characteristics:
- ES5-compatible syntax
- `function` declarations
- `Java.type(...)` interop where needed
- output in [`output-script/javascript/`](Bob_skill_Maximo_Java_Conversion/output-script/javascript)

## Nashorn

Use when the user explicitly wants Nashorn-compatible JavaScript.

Expected characteristics:
- Java interop patterns
- Maximo-compatible JavaScript structure
- output in [`output-script/nashorn/`](Bob_skill_Maximo_Java_Conversion/output-script/nashorn)

## ECMAScript

Use when the user wants ECMAScript output.

Expected characteristics:
- JavaScript-compatible structure
- output in [`output-script/ecmascript/`](Bob_skill_Maximo_Java_Conversion/output-script/ecmascript)

## MBR

Use when the user wants Maximo Business Rules output.

Expected characteristics:
- rule-based structure
- condition/action mapping
- `.mbr` output in [`output-script/mbr/`](Bob_skill_Maximo_Java_Conversion/output-script/mbr)

## Validation Expectations

Each generated script must satisfy:
1. business logic retained
2. target language syntax strategy valid
3. Maximo best practices applied