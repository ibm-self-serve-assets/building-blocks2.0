# Java Conversion Fundamentals

## Purpose

This document explains the fundamentals of converting IBM Maximo Java classes into automation scripts using the Maximo Java Conversion Bob skill.

## Core Principles

### 1. Preserve Business Logic
The converted script must preserve:
- validation rules
- field updates
- status transitions
- calculations
- conditional logic
- Maximo object interactions

### 2. Respect Target Language
The generated script must follow the syntax and conventions of the selected target language:
- [`python`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/skill.json)
- [`jython`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/skill.json)
- [`javascript`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/skill.json)
- [`nashorn`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/skill.json)
- [`ecmascript`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/skill.json)
- [`mbr`](Bob_skill_Maximo_Java_Conversion/.bob/skills/maximo-java-conversion/skill.json)

### 3. Apply Maximo Best Practices
The generated script should include:
- null checks
- safe exception handling
- Maximo-compatible APIs
- resource cleanup where applicable
- readable structure for review and deployment

## Runtime Workflow

The shared skill expects:
- user Java files in [`java-input/`](Bob_skill_Maximo_Java_Conversion/java-input)
- generated scripts in [`output-script/`](Bob_skill_Maximo_Java_Conversion/output-script)
- reports in [`conversion-reports/`](Bob_skill_Maximo_Java_Conversion/conversion-reports)

These folders should be created automatically by the converter when needed.

## Supported Java Patterns

Typical supported Maximo Java patterns include:
- `MboValueAdapter` validation classes
- `Mbo` extension classes
- `MboSet` helper classes
- field action logic
- status update logic
- labor and cost validation logic

## Validation Model

Every conversion is validated against three mandatory rules:
1. business logic retained
2. target language syntax strategy valid
3. Maximo best practices applied