# Java Conversion Example

## Scenario

A user has one or more legacy Maximo Java classes and wants equivalent automation-script output while preserving business logic and applying Maximo best practices.

## Input

Place Java files in [`java-input/`](Bob_skill_Maximo_Java_Conversion/java-input), for example:

- [`MaximoWorkOrderValidator.java`](MaximoWorkOrderValidator.java)
- [`WorkOrderLaborValidator.java`](WorkOrderLaborValidator.java)
- [`woExt.java`](woExt.java)

## Expected Flow

1. The skill scans [`java-input/`](Bob_skill_Maximo_Java_Conversion/java-input)
2. The skill prompts for a target language
3. The converter processes each `.java` file
4. Converted scripts are written to [`output-script/`](Bob_skill_Maximo_Java_Conversion/output-script)
5. Validation reports are written to [`conversion-reports/`](Bob_skill_Maximo_Java_Conversion/conversion-reports)

## Example Target Selection

Choose one of:

- `python`
- `jython`
- `javascript`
- `nashorn`
- `ecmascript`
- `mbr`

## Expected Result

For each Java file, the skill should produce:

- a converted script with valid target-language syntax
- preserved validation and business rules
- Maximo-safe API usage patterns
- a conversion report documenting checks and findings

## Validation Expectations

The generated result must satisfy all three mandatory rules:

1. preserve original Java business logic
2. generate valid syntax for the selected language
3. follow Maximo coding standards and best practices