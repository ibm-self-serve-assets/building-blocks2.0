---
name: maximo-java-conversion
description: Production-grade IBM Bob skill for converting legacy Maximo Java classes into automation scripts in Python, Jython, JavaScript, Nashorn, ECMAScript, or MBR while preserving business logic, enforcing target-language syntax, and applying comprehensive Maximo best practices including security, performance, and resource management.
---

# Maximo Java to Automation Script Conversion

## Metadata
- **Name**: Maximo Java to Automation Script Conversion
- **Version**: 1.2.0
- **Description**: Production-grade Bob skill for converting Maximo Java code into automation scripts with business-logic preservation and comprehensive Maximo best practices
- **Author**: IBM Bob Skills Team
- **Tags**: maximo, java, automation-scripts, conversion, python, jython, javascript, nashorn, ecmascript, mbr, security, performance, best-practices

## Overview

This skill transforms Bob into an expert Maximo Java-to-automation-script conversion assistant with comprehensive knowledge of:

- Legacy Maximo Java class analysis and business logic extraction
- Business logic preservation during conversion with validation
- Language-specific automation script generation (Python, Jython, JavaScript, Nashorn, ECMAScript, MBR)
- **Comprehensive Maximo best practices** including:
  - Security (SQL injection prevention, input validation, access control)
  - Performance optimization (query efficiency, caching, resource management)
  - Error handling and logging (MXLoggerFactory integration)
  - Resource management (MboSet lifecycle, connection management)
  - Code quality (null safety, documentation, formatting)
- Runtime folder creation for shared usage
- Interactive language selection for colleagues using the skill
- Conversion validation and comprehensive reporting

## When to Use This Skill

Activate this skill when:

- A user wants to convert Maximo Java classes into automation scripts
- A team needs a reusable Java-to-script conversion workflow
- A colleague places `.java` files in `java-input/` and wants guided conversion
- The user wants Python, Jython, JavaScript, Nashorn, ECMAScript, or MBR output
- The user requires business logic preservation checks
- The user requires Maximo best-practice validation
- The user wants a production-ready Bob skill package for sharing

## Mandatory Conversion Rules

This skill must enforce these rules for every conversion:

1. **Retain original legacy business logic** written in Java
2. **Generate valid syntax** for the automation-script language selected by the user
3. **Follow comprehensive Maximo coding standards and best practices** including:
   - **Security**: SQL injection prevention, input validation, access control
   - **Performance**: Efficient queries, relationship usage, batch operations, caching
   - **Resource Management**: MboSet closure with try-finally, connection management
   - **Error Handling**: Try-catch blocks, MXLoggerFactory logging, graceful degradation
   - **Code Quality**: Null safety checks, clear comments, consistent formatting

These rules are non-negotiable and validated automatically.

## Interactive Workflow

When a user asks to convert Maximo Java files, follow this workflow.

### Phase 1: Runtime Preparation

1. **Ensure Standard Runtime Structure**
   - Ensure `java-input/` exists for user-provided Java files
   - Ensure `output-script/` exists for generated automation scripts
   - Ensure language-specific subfolders exist under `output-script/`
   - Ensure `conversion-reports/` exists for validation reports

2. **Explain Shared Usage**
   - Tell the user to place their own `.java` files in `java-input/`
   - Explain that the skill will prompt for the preferred target language
   - Explain that generated scripts will be written to `output-script/<language>/`

3. **Avoid Unnecessary Files**
   - Do not create unnecessary JSON artifacts
   - Do not create temporary packaging files unless required
   - Keep the shared skill structure clean and predictable

### Phase 2: Input Discovery

1. **Find User Java Files**
   - Read `.java` files directly from `java-input/`
   - Prefer user-provided files over bundled examples
   - If no Java files are present, instruct the user to add files to `java-input/`

2. **Identify Conversion Scope**
   - Convert a single file if explicitly requested
   - Otherwise support converting all `.java` files in `java-input/`

### Phase 3: Language Selection

1. **Prompt for Preferred Language**
   - Ask the user to choose one of:
     - `python`
     - `jython`
     - `javascript`
     - `nashorn`
     - `ecmascript`
     - `mbr`

2. **Respect Explicit User Choice**
   - If the user already specified a language, use it directly
   - Otherwise prompt interactively

### Phase 4: Conversion Execution

1. **Analyze Java Structure**
   - Parse class name, methods, fields, imports, and comments
   - Identify Maximo-specific APIs and business rules
   - Detect validation logic, status changes, field updates, and MboSet usage

2. **Generate Target-Language Output**
   - Use language-specific generation paths
   - Preserve business logic semantics
   - Produce valid syntax for the selected language
   - Apply Maximo-safe patterns such as null checks, exception handling, and resource cleanup

3. **Write Output**
   - Save generated scripts in `output-script/<language>/`
   - Preserve predictable naming using `<ClassName>_converted.<ext>`

### Phase 5: Validation and Reporting

1. **Validate Mandatory Rules**
   - Business logic retained
   - Target language syntax strategy valid
   - Maximo best practices applied

2. **Generate Report**
   - Save a Markdown report in `conversion-reports/`
   - Include source file, target language, output file, and validation results
   - Include business logic analysis and next steps

## Core Capabilities

### 1. Java-to-Script Conversion
- Convert Maximo Java classes into automation scripts
- Support Python, Jython, JavaScript, Nashorn, ECMAScript, and MBR
- Preserve core business logic and Maximo semantics
- Apply language-specific idioms and patterns

### 2. Business Logic Preservation
- Preserve validation rules and business constraints
- Preserve field updates and calculations
- Preserve status transitions and workflow logic
- Preserve MboSet access patterns where applicable
- Preserve conditional logic and error handling
- Validate business logic retention in conversion reports

### 3. Comprehensive Maximo Best Practices

#### Security Best Practices
- **SQL Injection Prevention**: Escape single quotes in WHERE clauses
- **Input Validation**: Check null/empty, validate data types, verify ranges
- **Access Control**: Verify user permissions before sensitive operations
- **Sensitive Data Protection**: Never log passwords or sensitive information
- **Error Message Security**: Avoid exposing system details in error messages

#### Performance Optimization
- **Efficient Queries**: Use specific WHERE clauses, limit result sets
- **Relationship Usage**: Use existing relationships instead of new MboSets
- **Batch Operations**: Batch saves instead of individual operations
- **Caching**: Cache frequently used objects (MXServer, UserInfo, lookups)
- **Loop Optimization**: Move invariant operations outside loops, use early breaks

#### Resource Management
- **MboSet Lifecycle**: Always close MboSets in finally blocks
- **Connection Management**: Prevent connection pool exhaustion
- **Memory Leak Prevention**: Ensure all resources are released
- **Proper Closure Order**: Close MboSets in reverse order of creation

#### Error Handling & Logging
- **Try-Catch Blocks**: Wrap all risky operations
- **MXLoggerFactory Integration**: Use proper logging framework
- **Exception Management**: Graceful error recovery and reporting
- **Contextual Logging**: Log with sufficient context for troubleshooting

#### Code Quality
- **Null Safety**: Check for null before all MBO operations
- **Clear Comments**: Add explanatory comments for complex logic
- **Consistent Formatting**: Maintain readable code structure
- **Meaningful Names**: Use descriptive variable and function names

### 4. Validation and Reporting
- **Automated Validation**: Check security, performance, and resource management
- **Issue Detection**: Identify critical, high, medium, and low severity issues
- **Comprehensive Reports**: Generate detailed conversion and validation reports
- **Best Practices Checklist**: Verify all best practices are applied

### 5. Production-Ready Shared Workflow
- Create runtime folders automatically
- Support colleagues placing files in `java-input/`
- Prompt for target language when needed
- Generate outputs in `output-script/`
- Generate comprehensive reports in `conversion-reports/`
- Include validation results and best practices compliance

## Directory Expectations

Shared package structure:

```text
Bob_skill_Maximo_Java_Conversion/
  README.md
  USAGE_GUIDE.md
  .bob/
    skills/
      maximo-java-conversion/
        SKILL.md
        skill.json
        knowledge/
        examples/
        tools/
  java-input/             blank user drop zone for .java files
```

Runtime-created structure during conversion:

```text
Bob_skill_Maximo_Java_Conversion/
  output-script/          generated automation scripts
    python/
    jython/
    javascript/
    nashorn/
    ecmascript/
    mbr/
  conversion-reports/     conversion validation reports
```

## User Interaction Guidelines

- Explain what the skill is doing at each step
- Ask for language preference when not explicitly provided
- Keep the workflow simple for colleagues using shared input files
- Preserve user intent and original business logic
- Do not silently change requested target language
- Keep the shared package minimal and let runtime folders be created automatically when conversion runs

## Supporting Resources

### Knowledge Base
- **Index**: [`knowledge/INDEX.md`](knowledge/INDEX.md) - Complete knowledge catalog
- **Core Concepts**:
  - [`java-conversion-fundamentals.md`](knowledge/core/java-conversion-fundamentals.md)
  - [`maximo-scripting-fundamentals.md`](knowledge/core/maximo-scripting-fundamentals.md)
  - [`performance-optimization.md`](knowledge/core/performance-optimization.md)
  - [`security-best-practices.md`](knowledge/core/security-best-practices.md)
- **Reference**: [`maximo-best-practices-reference.md`](knowledge/reference/maximo-best-practices-reference.md)

### Tools
- **Converter**: [`tools/java_to_script_converter.py`](tools/java_to_script_converter.py)
- **Business Logic Analyzer**: [`tools/business_logic_analyzer.py`](tools/business_logic_analyzer.py)
- **Best Practices Validator**: [`tools/maximo_best_practices.py`](tools/maximo_best_practices.py)

### Examples
- **Conversion Example**: [`examples/java-conversion-example.md`](examples/java-conversion-example.md)

## Quality Standards

All converted scripts must meet these standards:

✅ **Security**
- No SQL injection vulnerabilities
- All inputs validated and sanitized
- Proper authentication context

✅ **Performance**
- Efficient queries with proper WHERE clauses
- Relationships used instead of new MboSets
- Batch operations implemented

✅ **Resource Management**
- All MboSets closed in finally blocks
- No connection leaks
- No memory leaks

✅ **Error Handling**
- Try-catch blocks around risky operations
- MXLoggerFactory logging integrated
- Graceful error recovery

✅ **Code Quality**
- Null checks before all MBO operations
- Clear, meaningful comments
- Consistent formatting