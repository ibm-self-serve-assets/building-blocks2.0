"""
Content quality evaluation tools.

Wraps MetricsEvaluator with quality metrics:
  - llm_as_judge       : LLM-based quality judgment (more nuanced than token-level)
  - llm_validation     : LLM-based validation of outputs
  - evasiveness        : Is the model dodging the question?
  - topic_relevance    : Is the response on-topic?
  - keyword_detection  : Check for specific keywords in outputs
  - regex_detection    : Regex-based content detection

All SDK imports are deferred to function bodies (lazy) to avoid
import-time side effects before env vars are set.
"""

from __future__ import annotations

import logging
from typing import Optional

from watsonx_gov_mcp.server import mcp

logger = logging.getLogger(__name__)

_QUALITY_METRIC_MAP = {
    "llm_as_judge":       "LLMAsJudgeMetric",
    "llm_validation":     "LLMValidationMetric",
    "evasiveness":        "EvasivenessMetric",
    "topic_relevance":    "TopicRelevanceMetric",
    "keyword_detection":  "KeywordDetectionMetric",
    "regex_detection":    "RegexDetectionMetric",
}


@mcp.tool()
def evaluate_content_quality(
    records: list[dict],
    metrics: list[str],
    input_field: str = "question",
    output_field: str = "generated_text",
    context_field: str = "context",
    reference_field: Optional[str] = "reference",
) -> dict:
    """Evaluate the quality of GenAI outputs using advanced quality metrics.

    These metrics go beyond basic relevance — they detect evasiveness, topic drift,
    and use LLM-as-judge for nuanced quality assessment.

    Available metrics (pass one or more):
      - "llm_as_judge"      : LLM-based quality judgment (more nuanced than token-level metrics)
      - "llm_validation"    : LLM-based validation of outputs against expectations
      - "evasiveness"       : Is the model avoiding or dodging the question?
      - "topic_relevance"   : Is the response on-topic for the question asked?
      - "keyword_detection" : Check for presence of specific keywords in outputs
      - "regex_detection"   : Regex-based pattern detection in outputs

    Returns per-record scores and aggregate statistics (mean, min, max) for each metric.

    Args:
        records: List of dicts. Each must contain keys matching input_field and
            output_field. Example:
            [{"question": "What is RAG?",
              "generated_text": "I cannot help with that.",
              "context": "RAG stands for Retrieval-Augmented Generation...",
              "reference": "RAG is a technique..."}]
        metrics: Which quality metrics to run. Allowed values: llm_as_judge,
            llm_validation, evasiveness, topic_relevance, keyword_detection,
            regex_detection.
        input_field: Column name for the user question (default: "question").
        output_field: Column name for the model's output (default: "generated_text").
        context_field: Column name for context (default: "context").
        reference_field: Column name for reference answer (default: "reference").
    """
    try:
        import pandas as pd
        from ibm_watsonx_gov.evaluators.metrics_evaluator import MetricsEvaluator
        from ibm_watsonx_gov.config import GenAIConfiguration
        import ibm_watsonx_gov.metrics as m

        unknown = set(metrics) - set(_QUALITY_METRIC_MAP)
        if unknown:
            return {
                "status": "error",
                "error": f"Unknown quality metrics: {sorted(unknown)}. Allowed: {sorted(_QUALITY_METRIC_MAP)}",
            }
        if not records:
            return {"status": "error", "error": "records list is empty."}

        metric_instances = [getattr(m, _QUALITY_METRIC_MAP[name])() for name in metrics]

        config = GenAIConfiguration(
            input_fields=[input_field],
            output_fields=[output_field],
            context_fields=[context_field],
            reference_fields=[reference_field] if reference_field else [],
        )

        df = pd.DataFrame(records)
        evaluator = MetricsEvaluator(configuration=config)
        result = evaluator.evaluate(data=df, metrics=metric_instances)

        aggregate = [
            {
                "metric": agg.name,
                "mean": agg.mean,
                "min": agg.min,
                "max": agg.max,
                "total_records": agg.total_records,
            }
            for agg in result.metrics_result
        ]

        return {
            "status": "success",
            "aggregate": aggregate,
            "records": [{k: v for k, v in r.items() if v is not None} for r in result.to_dict()],
        }

    except Exception as exc:
        logger.error("evaluate_content_quality failed: %s", exc, exc_info=True)
        return {"status": "error", "error": str(exc)}
