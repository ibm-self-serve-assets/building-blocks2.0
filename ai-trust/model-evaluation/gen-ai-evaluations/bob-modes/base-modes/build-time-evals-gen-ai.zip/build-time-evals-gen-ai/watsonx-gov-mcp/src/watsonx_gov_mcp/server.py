"""
watsonx governance MCP server — stdio transport.

Entry point: `watsonx-gov-mcp` (defined in pyproject.toml scripts).

Environment variables required:
  WATSONX_APIKEY   - IBM Cloud API key
  WATSONX_REGION   - Cloud region (default: us-south)
                     Options: us-south, eu-de, au-syd, ca-tor, jp-tok
"""

import logging
import sys

from mcp.server.fastmcp import FastMCP

# All logging goes to stderr — stdout is reserved for MCP protocol messages.
logging.basicConfig(stream=sys.stderr, level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP(
    name="watsonx-gov",
    instructions=(
        "This server exposes IBM watsonx governance capabilities:\n"
        "- RAG/GenAI quality evaluation (answer relevance, faithfulness, context relevance, retrieval ranking)\n"
        "- Content quality (LLM-as-judge, evasiveness, topic relevance, keyword/regex detection)\n"
        "- Safety & content detection (HAP, PII, jailbreak, prompt safety, social bias, violence, harm)\n"
        "- Readability (grade level, reading ease)\n"
        "- Operational (cost, duration, token counts)\n"
        "- Agentic AI evaluation (tool call accuracy and parameter correctness)\n"
        "- Governed tool catalog (list, get, register, delete governed tools)\n\n"
        "All evaluation tools accept lists of records and return per-record scores "
        "plus aggregate statistics. Set WATSONX_APIKEY and WATSONX_REGION env vars before use."
    ),
)

# Tool modules are imported AFTER mcp is created — each module imports `mcp`
# from this file and decorates its functions with @mcp.tool().
from watsonx_gov_mcp.tools import rag_eval         # noqa: E402, F401
from watsonx_gov_mcp.tools import safety           # noqa: E402, F401
from watsonx_gov_mcp.tools import agentic_eval     # noqa: E402, F401
from watsonx_gov_mcp.tools import tool_catalog     # noqa: E402, F401
from watsonx_gov_mcp.tools import quality_eval     # noqa: E402, F401
from watsonx_gov_mcp.tools import readability_eval # noqa: E402, F401
from watsonx_gov_mcp.tools import operational_eval # noqa: E402, F401


def main() -> None:
    logger.info("Starting watsonx-gov MCP server (stdio)")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
