"""
Operational evaluation tools.

Wraps MetricsEvaluator with operational metrics:
  - cost               : Token cost tracking
  - duration           : Response latency / duration
  - input_token_count  : Input token count
  - output_token_count : Output token count

All SDK imports are deferred to function bodies (lazy) to avoid
import-time side effects before env vars are set.
"""

from __future__ import annotations

import logging

from watsonx_gov_mcp.server import mcp

logger = logging.getLogger(__name__)

_OPERATIONAL_METRIC_MAP = {
    "cost":               "CostMetric",
    "duration":           "DurationMetric",
    "input_token_count":  "InputTokenCountMetric",
    "output_token_count": "OutputTokenCountMetric",
}


@mcp.tool()
def evaluate_operational(
    records: list[dict],
    metrics: list[str],
    input_field: str = "input_text",
    output_field: str = "generated_text",
) -> dict:
    """Evaluate operational characteristics of GenAI outputs — cost, latency, and token usage.

    These metrics help you understand the cost and performance profile of your
    GenAI application at build time, before deploying to production.

    Available metrics (pass one or more):
      - "cost"               : Estimated token cost per record
      - "duration"           : Response duration / latency
      - "input_token_count"  : Number of input tokens consumed
      - "output_token_count" : Number of output tokens generated

    Returns per-record values and aggregate statistics (mean, min, max) for each metric.

    Args:
        records: List of dicts. Each must contain keys matching input_field and/or
            output_field, depending on the metrics chosen. Example:
            [{"input_text": "What is RAG?",
              "generated_text": "RAG is a technique that combines retrieval with generation."}]
        metrics: Which operational metrics to run. Allowed values: cost, duration,
            input_token_count, output_token_count.
        input_field: Column name for input text (default: "input_text").
        output_field: Column name for output text (default: "generated_text").
    """
    try:
        import pandas as pd
        from ibm_watsonx_gov.evaluators.metrics_evaluator import MetricsEvaluator
        from ibm_watsonx_gov.config import GenAIConfiguration
        import ibm_watsonx_gov.metrics as m

        unknown = set(metrics) - set(_OPERATIONAL_METRIC_MAP)
        if unknown:
            return {
                "status": "error",
                "error": f"Unknown operational metrics: {sorted(unknown)}. Allowed: {sorted(_OPERATIONAL_METRIC_MAP)}",
            }
        if not records:
            return {"status": "error", "error": "records list is empty."}

        metric_instances = [getattr(m, _OPERATIONAL_METRIC_MAP[name])() for name in metrics]

        config = GenAIConfiguration(
            input_fields=[input_field],
            output_fields=[output_field],
        )

        df = pd.DataFrame(records)
        evaluator = MetricsEvaluator(configuration=config)
        result = evaluator.evaluate(data=df, metrics=metric_instances)

        aggregate = [
            {
                "metric": agg.name,
                "mean": agg.mean,
                "min": agg.min,
                "max": agg.max,
                "total_records": agg.total_records,
            }
            for agg in result.metrics_result
        ]

        return {
            "status": "success",
            "aggregate": aggregate,
            "records": [{k: v for k, v in r.items() if v is not None} for r in result.to_dict()],
        }

    except Exception as exc:
        logger.error("evaluate_operational failed: %s", exc, exc_info=True)
        return {"status": "error", "error": str(exc)}
