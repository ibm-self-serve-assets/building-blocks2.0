"""
Lazy singleton providing a shared ibm-watsonx-gov APIClient.

The client is constructed on first access, not at import time. This is
critical for stdio MCP servers: SDK initialization (which may make network
calls to IAM) must not happen during module import.

Required environment variables
-------------------------------
WATSONX_APIKEY   : IBM Cloud API key
WATSONX_REGION   : Cloud region (default: us-south)
                   Accepted: us-south, eu-de, au-syd, ca-tor, jp-tok

Usage
-----
    from watsonx_gov_mcp.client import get_client
    client = get_client()   # initializes on first call
"""

from __future__ import annotations

import logging
import os
import threading
from typing import Optional

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_client: Optional[object] = None


def get_client():
    """Return the shared APIClient, initializing it on first call.

    Raises
    ------
    RuntimeError
        If WATSONX_APIKEY is not set, or if SDK initialization fails.
    """
    global _client
    if _client is not None:
        return _client
    with _lock:
        if _client is not None:  # double-checked locking
            return _client
        api_key = os.environ.get("WATSONX_APIKEY")
        if not api_key:
            raise RuntimeError(
                "WATSONX_APIKEY environment variable is not set. "
                "Export it before starting the MCP server."
            )
        try:
            from ibm_watsonx_gov.clients.api_client import APIClient
            from ibm_watsonx_gov.entities.credentials import Credentials

            region = os.environ.get("WATSONX_REGION", "us-south")
            creds = Credentials(api_key=api_key, region=region)
            _client = APIClient(credentials=creds)
            logger.info("watsonx.governance APIClient initialized (region=%s)", region)
        except Exception as exc:
            logger.error("Failed to initialize APIClient: %s", exc)
            raise RuntimeError(f"APIClient initialization failed: {exc}") from exc
    return _client


def reset_client() -> None:
    """Force re-initialization on next call. Used in tests."""
    global _client
    with _lock:
        _client = None
