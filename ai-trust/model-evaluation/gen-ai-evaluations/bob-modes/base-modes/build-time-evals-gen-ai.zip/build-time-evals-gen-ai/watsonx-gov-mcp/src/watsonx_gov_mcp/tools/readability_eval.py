"""
Readability evaluation tools.

Wraps MetricsEvaluator with readability metrics:
  - text_grade_level   : Reading grade level of the text
  - text_reading_ease  : Reading ease score (Flesch-based)

All SDK imports are deferred to function bodies (lazy) to avoid
import-time side effects before env vars are set.
"""

from __future__ import annotations

import logging

from watsonx_gov_mcp.server import mcp

logger = logging.getLogger(__name__)

_READABILITY_METRIC_MAP = {
    "text_grade_level":   "TextGradeLevelMetric",
    "text_reading_ease":  "TextReadingEaseMetric",
}


@mcp.tool()
def evaluate_readability(
    records: list[dict],
    metrics: list[str],
    output_field: str = "generated_text",
) -> dict:
    """Evaluate the readability of GenAI outputs.

    Measures how easy or difficult the generated text is to read — useful for
    ensuring outputs match the target audience's reading level.

    Available metrics (pass one or more):
      - "text_grade_level"  : US school grade level needed to understand the text
      - "text_reading_ease" : Flesch Reading Ease score (higher = easier to read)

    Returns per-record scores and aggregate statistics (mean, min, max) for each metric.

    Args:
        records: List of dicts. Each must contain a key matching output_field. Example:
            [{"generated_text": "RAG is a technique that combines retrieval with generation."}]
        metrics: Which readability metrics to run. Allowed values: text_grade_level,
            text_reading_ease.
        output_field: Column name for the text to evaluate (default: "generated_text").
    """
    try:
        import pandas as pd
        from ibm_watsonx_gov.evaluators.metrics_evaluator import MetricsEvaluator
        from ibm_watsonx_gov.config import GenAIConfiguration
        import ibm_watsonx_gov.metrics as m

        unknown = set(metrics) - set(_READABILITY_METRIC_MAP)
        if unknown:
            return {
                "status": "error",
                "error": f"Unknown readability metrics: {sorted(unknown)}. Allowed: {sorted(_READABILITY_METRIC_MAP)}",
            }
        if not records:
            return {"status": "error", "error": "records list is empty."}

        metric_instances = [getattr(m, _READABILITY_METRIC_MAP[name])() for name in metrics]

        config = GenAIConfiguration(
            output_fields=[output_field],
        )

        df = pd.DataFrame(records)
        evaluator = MetricsEvaluator(configuration=config)
        result = evaluator.evaluate(data=df, metrics=metric_instances)

        aggregate = [
            {
                "metric": agg.name,
                "mean": agg.mean,
                "min": agg.min,
                "max": agg.max,
                "total_records": agg.total_records,
            }
            for agg in result.metrics_result
        ]

        return {
            "status": "success",
            "aggregate": aggregate,
            "records": [{k: v for k, v in r.items() if v is not None} for r in result.to_dict()],
        }

    except Exception as exc:
        logger.error("evaluate_readability failed: %s", exc, exc_info=True)
        return {"status": "error", "error": str(exc)}
