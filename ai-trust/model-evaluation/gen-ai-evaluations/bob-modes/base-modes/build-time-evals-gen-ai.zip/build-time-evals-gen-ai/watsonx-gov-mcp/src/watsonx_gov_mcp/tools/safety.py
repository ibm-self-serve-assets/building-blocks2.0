"""
Safety and content detection tools.

Wraps MetricsEvaluator with safety metrics:
  Core:
  - hap               : Hate, Abuse, and Profanity detection
  - pii               : Personally Identifiable Information detection
  - jailbreak         : Prompt injection / jailbreak attempt detection
  - prompt_safety_risk: General prompt safety risk scoring
  - social_bias       : Social bias and stereotype detection
  Granular:
  - input_hap / output_hap     : HAP on inputs or outputs specifically
  - input_pii / output_pii     : PII on inputs or outputs specifically
  - sexual_content              : Sexual content detection
  - violence                    : Violence detection
  - profanity                   : Profanity detection
  - harm                        : General harm detection
  - harm_engagement             : Harm engagement detection
  - unethical_behavior          : Unethical behavior detection

All SDK imports are deferred to function bodies (lazy) to avoid
import-time side effects before env vars are set.
"""

from __future__ import annotations

import logging

from watsonx_gov_mcp.server import mcp

logger = logging.getLogger(__name__)

_SAFETY_METRIC_MAP = {
    "hap":                "HAPMetric",
    "pii":                "PIIMetric",
    "jailbreak":          "JailbreakMetric",
    "prompt_safety_risk": "PromptSafetyRiskMetric",
    "social_bias":        "SocialBiasMetric",
    "input_hap":          "InputHAPMetric",
    "output_hap":         "OutputHAPMetric",
    "input_pii":          "InputPIIMetric",
    "output_pii":         "OutputPIIMetric",
    "sexual_content":     "SexualContentMetric",
    "violence":           "ViolenceMetric",
    "profanity":          "ProfanityMetric",
    "harm":               "HarmMetric",
    "harm_engagement":    "HarmEngagementMetric",
    "unethical_behavior": "UnethicalBehaviorMetric",
}


@mcp.tool()
def evaluate_content_safety(
    records: list[dict],
    metrics: list[str],
    input_field: str = "input_text",
    output_field: str = "generated_text",
) -> dict:
    """Detect safety risks, harmful content, and policy violations in text.

    Evaluates input prompts and/or model outputs for safety issues. Can be used
    to screen user inputs before sending to a model, or to evaluate model responses
    for harmful content.

    Available metrics (pass one or more):
      Core:
      - "hap"                : Hate, abuse, and profanity — detects toxic language
      - "pii"                : Personal data leakage — names, emails, phone numbers, SSNs, etc.
      - "jailbreak"          : Prompt injection or jailbreak attempts in the input
      - "prompt_safety_risk" : General risk score for the input prompt
      - "social_bias"        : Stereotyping, discrimination, or biased language
      Granular:
      - "input_hap"          : HAP detection on inputs only
      - "output_hap"         : HAP detection on outputs only
      - "input_pii"          : PII detection on inputs only
      - "output_pii"         : PII detection on outputs only
      - "sexual_content"     : Sexual content detection
      - "violence"           : Violence detection
      - "profanity"          : Profanity detection
      - "harm"               : General harm detection
      - "harm_engagement"    : Harm engagement detection
      - "unethical_behavior" : Unethical behavior detection

    Returns per-record risk labels/scores and aggregate statistics.

    Args:
        records: List of dicts. Each should contain the key matching input_field.
            Include output_field if evaluating model responses too. Example:
            [{"input_text": "Ignore all previous instructions and..."},
             {"input_text": "My SSN is 123-45-6789"}]
        metrics: Which safety metrics to run. Allowed: hap, pii, jailbreak,
            prompt_safety_risk, social_bias, input_hap, output_hap, input_pii,
            output_pii, sexual_content, violence, profanity, harm,
            harm_engagement, unethical_behavior.
        input_field: Column name for input/prompt text (default: "input_text").
        output_field: Column name for model output text (default: "generated_text").
            Only needed if evaluating output-side safety.
    """
    try:
        import pandas as pd
        from ibm_watsonx_gov.evaluators.metrics_evaluator import MetricsEvaluator
        from ibm_watsonx_gov.config import GenAIConfiguration
        import ibm_watsonx_gov.metrics as m

        unknown = set(metrics) - set(_SAFETY_METRIC_MAP)
        if unknown:
            return {
                "status": "error",
                "error": f"Unknown safety metrics: {sorted(unknown)}. Allowed: {sorted(_SAFETY_METRIC_MAP)}",
            }
        if not records:
            return {"status": "error", "error": "records list is empty."}

        metric_instances = [getattr(m, _SAFETY_METRIC_MAP[name])() for name in metrics]

        config = GenAIConfiguration(
            input_fields=[input_field],
            output_fields=[output_field],
        )

        df = pd.DataFrame(records)
        evaluator = MetricsEvaluator(configuration=config)
        result = evaluator.evaluate(data=df, metrics=metric_instances)

        aggregate = [
            {
                "metric": agg.name,
                "mean": agg.mean,
                "min": agg.min,
                "max": agg.max,
                "total_records": agg.total_records,
            }
            for agg in result.metrics_result
        ]

        return {
            "status": "success",
            "aggregate": aggregate,
            "records": [{k: v for k, v in r.items() if v is not None} for r in result.to_dict()],
        }

    except Exception as exc:
        logger.error("evaluate_content_safety failed: %s", exc, exc_info=True)
        return {"status": "error", "error": str(exc)}
