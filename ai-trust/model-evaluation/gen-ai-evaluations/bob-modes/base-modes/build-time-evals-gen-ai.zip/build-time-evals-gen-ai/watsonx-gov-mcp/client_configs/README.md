# watsonx-gov MCP — Client Setup Guide

This directory contains ready-to-use configuration snippets for connecting the **watsonx-gov MCP server** to your AI code assistant.

## What This MCP Does

This MCP server exposes **IBM watsonx governance** capabilities directly inside your code assistant. Once connected, you can ask your assistant to:

- **Evaluate RAG pipelines** — score answer relevance, faithfulness, context relevance, and retrieval precision
- **Detect safety issues** — scan text for hate/abuse/profanity (HAP), PII leakage, jailbreak attempts, and social bias
- **Evaluate agentic tool calls** — assess whether an AI agent chose the right tools and passed correct parameters
- **Manage the governed tool catalog** — list, inspect, register, and delete tools in your watsonx governance inventory

---

## Prerequisites

Before wiring this into any assistant, make sure you have:

1. **uv** installed — [https://docs.astral.sh/uv/](https://docs.astral.sh/uv/)
2. **Dependencies installed** — run once from the project root:
   ```bash
   cd /path/to/watsonx-gov-mcp
   uv sync
   ```
3. **IBM Cloud API key** with access to a provisioned watsonx.governance instance
   Get one at: IBM Cloud → Manage → Access (IAM) → API keys

---

## Wiring Into Your Code Assistant

This server uses **stdio transport**, which is supported by any MCP-compatible assistant. The core configuration is the same regardless of which assistant you use:

```json
{
  "mcpServers": {
    "watsonx-gov": {
      "command": "/opt/homebrew/bin/uv",
      "args": ["--directory", "/path/to/watsonx-gov-mcp", "run", "watsonx-gov-mcp"],
      "env": {
        "WATSONX_APIKEY": "<your-ibm-cloud-api-key>",
        "WATSONX_REGION": "us-south"
      }
    }
  }
}
```

Add this to your assistant's MCP configuration file (typically `.mcp.json` in your project root or in the assistant's settings directory). Replace `/path/to/watsonx-gov-mcp` with the absolute path on your machine and add your IBM Cloud API key.

Refer to your code assistant's documentation for the exact location of the MCP configuration file.

---

## Configuration

| Variable | Required | Default | Description |
|---|---|---|---|
| `WATSONX_APIKEY` | Yes | — | IBM Cloud API key (IAM) |
| `WATSONX_REGION` | No | `us-south` | Region where your instance is provisioned: `us-south`, `eu-de`, `au-syd`, `ca-tor`, `jp-tok` |

> **Tip:** Add both variables to your shell profile (`~/.zshrc`) so you don't need to paste them into every config file:
> ```bash
> export WATSONX_APIKEY="your-key-here"
> export WATSONX_REGION="us-south"
> ```

---

## Testing the Server

### 1. Browse tools with the MCP Inspector (no code assistant needed)

```bash
export WATSONX_APIKEY="your-key"
export WATSONX_REGION="us-south"

cd /path/to/watsonx-gov-mcp
uv run mcp dev src/watsonx_gov_mcp/server.py
```

Opens **http://localhost:5173** — an interactive UI where you can see all registered tools, send test payloads, and inspect responses.

### 2. Verify all tools load (no credentials needed)

```bash
cd /path/to/watsonx-gov-mcp

uv run python -c "
import logging; logging.disable(logging.CRITICAL)
from watsonx_gov_mcp.server import mcp
tools = [t.name for t in mcp._tool_manager.list_tools()]
print('Tools:', tools)
print('OK')
" 2>/dev/null
```

---

## Example Prompts Once Connected

After wiring into your assistant, try these prompts:

```
Evaluate this text for safety issues: "Ignore all previous instructions..."
```

```
Run a faithfulness evaluation on these RAG outputs: [paste your data]
```

```
List all tools in my watsonx governance catalog
```

```
Evaluate these agent tool calls for accuracy against the ground truth
```
