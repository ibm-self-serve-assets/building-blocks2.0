"""
IBM watsonx governance Governed Tool Catalog tools.

Manages tool assets in the watsonx governance factsheet/inventory system.
These are governed metadata records for AI tools — not invocable tools themselves.

IMPORTANT: All SDK imports are inside function bodies (lazy). The AIToolClient
module calls environment.get_base_url() at import time, which requires
WATSONX_APIKEY to already be set. Lazy imports ensure this only runs when
a tool is actually invoked, by which point env vars are guaranteed to be present.
"""

from __future__ import annotations

import logging
from typing import Optional

from watsonx_gov_mcp.server import mcp

logger = logging.getLogger(__name__)




@mcp.tool()
def list_governed_tools(
    tool_name: Optional[str] = None,
    category: Optional[str] = None,
    inventory_id: Optional[str] = None,
    framework: Optional[str] = None,
    search_text: Optional[str] = None,
    offset: int = 0,
    limit: int = 50,
) -> dict:
    """List AI tools registered in the IBM watsonx governance tool catalog.

    Returns tool metadata records from the watsonx governance factsheet inventory.
    These are governed records describing AI tools — not calls to the tools themselves.
    All filters are optional; omit them to list all tools.

    Args:
        tool_name: Filter by exact tool name.
        category: Filter by tool category (e.g., "SEARCH", "DATABASE", "OTHER").
        inventory_id: Scope to a specific inventory GUID.
        framework: Filter by framework (e.g., "LANGCHAIN", "LANGGRAPH").
        search_text: Free-text search across tool names and descriptions.
        offset: Pagination offset (default: 0).
        limit: Maximum number of results to return (default: 50).
    """
    try:
        from ibm_watsonx_gov.tools.clients.ai_tool_client import list_tools
        kwargs = {k: v for k, v in {
            "tool_name": tool_name,
            "category": category,
            "inventory_id": inventory_id,
            "framework": framework,
            "search_text": search_text,
            "offset": offset,
            "limit": limit,
        }.items() if v is not None}
        result = list_tools(**kwargs)
        return {"status": "success", "tools": result}
    except Exception as exc:
        logger.error("list_governed_tools failed: %s", exc, exc_info=True)
        return {"status": "error", "error": str(exc)}


@mcp.tool()
def get_governed_tool(tool_id: str, inventory_id: str) -> dict:
    """Retrieve the full metadata record for a specific tool in the watsonx governance catalog.

    Returns the tool's name, description, code or endpoint details, schema,
    framework tags, and governance metadata.

    Args:
        tool_id: The asset GUID of the tool (e.g., "23dd7ec8-3d13-4f8f-a485-10278287b123").
        inventory_id: The inventory GUID the tool belongs to.
    """
    try:
        from ibm_watsonx_gov.tools.clients.ai_tool_client import get_tool
        result = get_tool(tool_id=tool_id, inventory_id=inventory_id)
        return {"status": "success", "tool": result}
    except Exception as exc:
        logger.error("get_governed_tool failed: %s", exc, exc_info=True)
        return {"status": "error", "error": str(exc)}


@mcp.tool()
def register_governed_tool(tool_definition: dict) -> dict:
    """Register a new AI tool in the IBM watsonx governance tool catalog.

    Creates a governed metadata record for the tool in the factsheet inventory.
    The tool_definition must include at minimum: tool_name and description.

    Required fields in tool_definition:
      - tool_name (str)   : Unique name for the tool
      - description (str) : What the tool does

    Optional fields:
      - display_name (str)         : Human-readable display name
      - framework (list[str])      : e.g., ["LANGCHAIN", "LANGGRAPH"]
      - category (str)             : e.g., "SEARCH", "DATABASE", "OTHER"
      - inventory_id (str)         : Target inventory GUID
      - code (dict)                : Source code details with keys:
          - source_code_base64 (str)   : Base64-encoded source code
          - run_time_details (dict)    : e.g., {"engine": "python 3.11.0"}
      - endpoint (dict)            : For API-based tools:
          - url (str)              : Endpoint URL
          - method (str)           : HTTP method (GET, POST, etc.)
      - schema (dict)              : JSON schema for tool parameters

    Example:
        {
          "tool_name": "weather_lookup",
          "description": "Fetch current weather for a city",
          "category": "OTHER",
          "schema": {
            "properties": {
              "city": {"type": "string", "description": "City name"}
            }
          }
        }

    Args:
        tool_definition: Tool registration payload dict (see above).
    """
    try:
        from ibm_watsonx_gov.tools.clients.ai_tool_client import register_tool
        result = register_tool(payload=tool_definition)
        return {"status": "success", "result": result}
    except Exception as exc:
        logger.error("register_governed_tool failed: %s", exc, exc_info=True)
        return {"status": "error", "error": str(exc)}


@mcp.tool()
def delete_governed_tool(tool_id: str, inventory_id: str) -> dict:
    """Delete a tool from the IBM watsonx governance tool catalog.

    Permanently removes the governance record for the tool.
    This does not affect any deployed or running instance of the tool itself —
    only the governance metadata record is deleted.

    Args:
        tool_id: The asset GUID of the tool to delete.
        inventory_id: The inventory GUID the tool belongs to.
    """
    try:
        from ibm_watsonx_gov.tools.clients.ai_tool_client import delete_tool
        result = delete_tool(tool_id=tool_id, inventory_id=inventory_id)
        return {"status": "success", "message": str(result)}
    except Exception as exc:
        logger.error("delete_governed_tool failed: %s", exc, exc_info=True)
        return {"status": "error", "error": str(exc)}
