"""
RAG and GenAI quality evaluation tools.

Wraps MetricsEvaluator with RAG quality and retrieval metrics:
  - answer_relevance      : How well the answer addresses the question
  - answer_similarity     : Semantic similarity to a reference answer
  - context_relevance     : How relevant the retrieved context is to the question
  - faithfulness          : Whether the answer is grounded in the provided context
  - retrieval_precision   : Fraction of retrieved chunks that are relevant
  - ndcg                  : Normalized Discounted Cumulative Gain (ranking quality)
  - hit_rate              : Did relevant documents appear in results?
  - average_precision     : Precision across retrieval ranks
  - reciprocal_rank       : Where does the first relevant result appear?

All SDK imports are deferred to function bodies (lazy) to avoid
import-time side effects before env vars are set.
"""

from __future__ import annotations

import logging
from typing import Optional

from watsonx_gov_mcp.server import mcp

logger = logging.getLogger(__name__)

_METRIC_MAP = {
    "answer_relevance":    "AnswerRelevanceMetric",
    "answer_similarity":   "AnswerSimilarityMetric",
    "context_relevance":   "ContextRelevanceMetric",
    "faithfulness":        "FaithfulnessMetric",
    "retrieval_precision": "RetrievalPrecisionMetric",
    "ndcg":                "NDCGMetric",
    "hit_rate":            "HitRateMetric",
    "average_precision":   "AveragePrecisionMetric",
    "reciprocal_rank":     "ReciprocalRankMetric",
}


@mcp.tool()
def evaluate_rag_quality(
    records: list[dict],
    metrics: list[str],
    input_field: str = "question",
    context_field: str = "context",
    output_field: str = "generated_text",
    reference_field: Optional[str] = "reference",
) -> dict:
    """Evaluate the quality of a RAG (Retrieval-Augmented Generation) pipeline.

    Pass a list of records — each containing the original question, the retrieved
    context, and the generated answer. Optionally include a reference answer for
    similarity-based metrics.

    Available metrics (pass one or more):
      - "answer_relevance"    : Does the answer address the question?
      - "answer_similarity"   : How similar is the answer to the reference? (requires reference_field)
      - "context_relevance"   : Is the retrieved context relevant to the question?
      - "faithfulness"        : Is the answer grounded in the provided context?
      - "retrieval_precision" : What fraction of retrieved context chunks are relevant?
      - "ndcg"                : Normalized Discounted Cumulative Gain (ranking quality)
      - "hit_rate"            : Did relevant documents appear in the results?
      - "average_precision"   : Precision across retrieval ranks
      - "reciprocal_rank"     : Where does the first relevant result appear?

    Returns per-record scores and aggregate statistics (mean, min, max) for each metric.

    Args:
        records: List of dicts. Each must contain keys matching input_field,
            context_field, and output_field. Example:
            [{"question": "What is RAG?",
              "context": "RAG stands for Retrieval-Augmented Generation...",
              "generated_text": "RAG is a technique that combines retrieval with generation.",
              "reference": "RAG stands for Retrieval-Augmented Generation."}]
        metrics: Which metrics to run. Allowed values: answer_relevance,
            answer_similarity, context_relevance, faithfulness, retrieval_precision,
            ndcg, hit_rate, average_precision, reciprocal_rank.
        input_field: Column name for the user question (default: "question").
        context_field: Column name for retrieved context (default: "context").
        output_field: Column name for the model's generated answer (default: "generated_text").
        reference_field: Column name for the reference/ground-truth answer (default: "reference").
            Only required for answer_similarity.
    """
    try:
        import pandas as pd
        from ibm_watsonx_gov.evaluators.metrics_evaluator import MetricsEvaluator
        from ibm_watsonx_gov.config import GenAIConfiguration
        import ibm_watsonx_gov.metrics as m

        unknown = set(metrics) - set(_METRIC_MAP)
        if unknown:
            return {
                "status": "error",
                "error": f"Unknown metrics: {sorted(unknown)}. Allowed: {sorted(_METRIC_MAP)}",
            }
        if not records:
            return {"status": "error", "error": "records list is empty."}

        metric_instances = [getattr(m, _METRIC_MAP[name])() for name in metrics]

        config = GenAIConfiguration(
            input_fields=[input_field],
            context_fields=[context_field],
            output_fields=[output_field],
            reference_fields=[reference_field] if reference_field else [],
        )

        df = pd.DataFrame(records)
        evaluator = MetricsEvaluator(configuration=config)
        result = evaluator.evaluate(data=df, metrics=metric_instances)

        aggregate = [
            {
                "metric": agg.name,
                "mean": agg.mean,
                "min": agg.min,
                "max": agg.max,
                "total_records": agg.total_records,
            }
            for agg in result.metrics_result
        ]

        return {
            "status": "success",
            "aggregate": aggregate,
            "records": [{k: v for k, v in r.items() if v is not None} for r in result.to_dict()],
        }

    except Exception as exc:
        logger.error("evaluate_rag_quality failed: %s", exc, exc_info=True)
        return {"status": "error", "error": str(exc)}
