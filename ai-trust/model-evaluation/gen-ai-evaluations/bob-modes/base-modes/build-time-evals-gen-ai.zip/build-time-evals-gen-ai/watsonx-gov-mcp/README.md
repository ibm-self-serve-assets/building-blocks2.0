# watsonx-gov MCP Server

An MCP (Model Context Protocol) server that exposes [IBM watsonx governance](https://www.ibm.com/products/watsonx-governance) SDK capabilities to any MCP-compatible AI code assistant.

## Capabilities

| Tool | Description |
|---|---|
| `evaluate_rag_quality` | RAG quality + retrieval: answer relevance, faithfulness, context relevance, similarity, retrieval precision, NDCG, hit rate, average precision, reciprocal rank |
| `evaluate_content_safety` | Safety detection: HAP, PII, jailbreak, prompt safety, social bias, sexual content, violence, profanity, harm, unethical behavior (+ input/output-specific variants) |
| `evaluate_content_quality` | Content quality: LLM-as-judge, LLM validation, evasiveness, topic relevance, keyword detection, regex detection |
| `evaluate_readability` | Readability: text grade level, reading ease |
| `evaluate_operational` | Operational: cost, duration, input/output token counts |
| `evaluate_agentic_tool_calls` | Agentic: tool call accuracy, parameter correctness, relevance, syntactic validity |
| `list_governed_tools` | List tools registered in the watsonx governance catalog |
| `get_governed_tool` | Get full metadata for a specific governed tool |
| `register_governed_tool` | Register a new tool in the governance catalog |
| `delete_governed_tool` | Delete a tool from the governance catalog |

## Prerequisites

- Python 3.11–3.13
- [uv](https://docs.astral.sh/uv/) package manager
- IBM Cloud API key with access to watsonx.governance

## Setup

> **Before anything else:** replace `/path/to/watsonx-gov-mcp` everywhere in this README and in `client_configs/` with the **absolute path to where you cloned this repo** on your machine. For example: `/Users/yourname/src/watsonx-gov-mcp`.

```bash
cd /path/to/watsonx-gov-mcp

# Install dependencies (creates .venv automatically)
uv sync
```

## Wiring into Your AI Assistant

This server uses **stdio transport**, which is supported by any MCP-compatible assistant. Register it by pointing your assistant's MCP config at the `watsonx-gov-mcp` entry point:

```json
{
  "command": "/opt/homebrew/bin/uv",
  "args": ["--directory", "/path/to/watsonx-gov-mcp", "run", "watsonx-gov-mcp"],
  "env": {
    "WATSONX_APIKEY": "<your-ibm-cloud-api-key>",
    "WATSONX_REGION": "us-south"
  }
}
```

> Replace `/path/to/watsonx-gov-mcp` with the absolute path on your machine, and `<your-ibm-cloud-api-key>` with your IBM Cloud API key.

The `client_configs/` directory contains ready-to-use configuration snippets for popular MCP-compatible code assistants.

## Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `WATSONX_APIKEY` | Yes | — | IBM Cloud API key |
| `WATSONX_REGION` | No | `us-south` | Cloud region: `us-south`, `eu-de`, `au-syd`, `ca-tor`, `jp-tok` |

## Testing

### Browse tools with the MCP Inspector

```bash
export WATSONX_APIKEY="your-key"
export WATSONX_REGION="us-south"
uv run mcp dev src/watsonx_gov_mcp/server.py
# Opens http://localhost:5173 — browse all 7 tools and send test payloads
```

### Quick smoke test (no network needed — tests server startup)

```bash
uv run python -c "
import sys
sys.stderr = open('/dev/null', 'w')  # suppress startup logs
from watsonx_gov_mcp.server import mcp
tools = [t.name for t in mcp._tool_manager.list_tools()]
print('Registered tools:', tools)
assert len(tools) == 7, f'Expected 7 tools, got {len(tools)}'
print('OK')
"
```

### Test a safety evaluation (requires real credentials)

```bash
export WATSONX_APIKEY="your-key"
uv run python -c "
from watsonx_gov_mcp.tools.safety import evaluate_content_safety
import json
result = evaluate_content_safety(
    records=[{'input_text': 'Hello, how are you?'}],
    metrics=['hap']
)
print(json.dumps(result, indent=2))
"
```

## Architecture Notes

- **Transport**: stdio — works with any MCP-compatible client
- **Lazy SDK imports**: All `ibm-watsonx-gov` imports happen inside tool function bodies, not at module load time. This prevents startup failures when env vars are set after import.
- **Error handling**: All tools return `{"status": "error", "error": "..."}` rather than raising exceptions — this prevents MCP protocol failures and lets the AI assistant report errors gracefully.
- **No stdout writes**: All logging uses `sys.stderr`. stdout is reserved for MCP protocol messages.
- **AgenticEvaluator vs MetricsEvaluator**: The `AgenticEvaluator` is a live-tracing singleton (OpenTelemetry lifecycle). For offline batch evaluation of recorded traces, `MetricsEvaluator` with `AgenticAIConfiguration` is used instead.
