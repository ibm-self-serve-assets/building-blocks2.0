"""
Agentic AI evaluation tools.

Evaluates the quality of an AI agent's tool-calling behavior by running
MetricsEvaluator with tool-call-specific metrics:
  - tool_call_accuracy           : Whether the correct tool was called
  - tool_call_parameter_accuracy : Whether correct parameters were passed
  - tool_call_relevance          : Whether the tool call was relevant to the task
  - tool_call_syntactic_accuracy : Whether the tool call was syntactically valid

Note: These metrics operate on batch (recorded) tool-call data, not on live
agent traces. AgenticEvaluator (the live-tracing singleton) is not used here
because it is incompatible with the request/response MCP tool pattern.
AgenticAIConfiguration is used in place of GenAIConfiguration to correctly
map tool-call-specific fields.

All SDK imports are deferred to function bodies (lazy) to avoid
import-time side effects before env vars are set.
"""

from __future__ import annotations

import logging

from watsonx_gov_mcp.server import mcp

logger = logging.getLogger(__name__)

_AGENTIC_METRIC_MAP = {
    "tool_call_accuracy":            "ToolCallAccuracyMetric",
    "tool_call_parameter_accuracy":  "ToolCallParameterAccuracyMetric",
    "tool_call_relevance":           "ToolCallRelevanceMetric",
    "tool_call_syntactic_accuracy":  "ToolCallSyntacticAccuracyMetric",
}


@mcp.tool()
def evaluate_agentic_tool_calls(
    records: list[dict],
    metrics: list[str],
    input_field: str = "input_text",
    output_field: str = "generated_text",
    tool_calls_field: str = "tool_calls",
    available_tools_field: str = "available_tools",
    reference_field: str = "ground_truth",
) -> dict:
    """Evaluate the quality of an AI agent's tool-calling behavior from recorded trace data.

    Use this to assess whether an agent chose the right tools, passed correct parameters,
    and made syntactically valid calls — based on a snapshot of tool-call records.
    This is for offline/batch evaluation of recorded agent traces, not live tracing.

    Available metrics (pass one or more):
      - "tool_call_accuracy"           : Did the agent call the correct tool?
      - "tool_call_parameter_accuracy" : Were the parameter values correct?
      - "tool_call_relevance"          : Was the tool call relevant to the user's request?
      - "tool_call_syntactic_accuracy" : Was the tool call structurally/syntactically valid?

    Returns per-record scores and aggregate statistics.

    Args:
        records: List of dicts, each describing one tool-call turn. Example:
            [{
              "input_text": "What is the weather in Paris?",
              "generated_text": "I'll check the weather for you.",
              "tool_calls": [{"name": "get_weather", "parameters": {"city": "Paris"}}],
              "available_tools": [{"name": "get_weather", "description": "Fetches weather data",
                                   "parameters": {"city": {"type": "string"}}}],
              "ground_truth": [{"name": "get_weather", "parameters": {"city": "Paris"}}]
            }]
        metrics: Which agentic metrics to run. Allowed: tool_call_accuracy,
            tool_call_parameter_accuracy, tool_call_relevance, tool_call_syntactic_accuracy.
        input_field: Column name for the user's query (default: "input_text").
        output_field: Column name for the agent's text response (default: "generated_text").
        tool_calls_field: Column name for the list of tool calls made (default: "tool_calls").
        available_tools_field: Column name for available tool schemas (default: "available_tools").
        reference_field: Column name for ground-truth / expected tool calls (default: "ground_truth").
    """
    try:
        import pandas as pd
        from ibm_watsonx_gov.evaluators.metrics_evaluator import MetricsEvaluator
        from ibm_watsonx_gov.config import AgenticAIConfiguration
        import ibm_watsonx_gov.metrics as m

        unknown = set(metrics) - set(_AGENTIC_METRIC_MAP)
        if unknown:
            return {
                "status": "error",
                "error": f"Unknown agentic metrics: {sorted(unknown)}. Allowed: {sorted(_AGENTIC_METRIC_MAP)}",
            }
        if not records:
            return {"status": "error", "error": "records list is empty."}

        metric_instances = [getattr(m, _AGENTIC_METRIC_MAP[name])() for name in metrics]

        config = AgenticAIConfiguration(
            input_fields=[input_field],
            output_fields=[output_field],
            tool_calls_field=tool_calls_field,
            available_tools_field=available_tools_field,
            reference_fields=[reference_field],
        )

        df = pd.DataFrame(records)
        evaluator = MetricsEvaluator(configuration=config)
        result = evaluator.evaluate(data=df, metrics=metric_instances)

        aggregate = [
            {
                "metric": agg.name,
                "mean": agg.mean,
                "min": agg.min,
                "max": agg.max,
                "total_records": agg.total_records,
            }
            for agg in result.metrics_result
        ]

        return {
            "status": "success",
            "aggregate": aggregate,
            "records": [{k: v for k, v in r.items() if v is not None} for r in result.to_dict()],
        }

    except Exception as exc:
        logger.error("evaluate_agentic_tool_calls failed: %s", exc, exc_info=True)
        return {"status": "error", "error": str(exc)}
