# QSE Command Construction Guide

## Overview
Detailed instructions for constructing Quantum Safe Explorer CLI commands based on project context, language, and scan type.

---

## Command Anatomy

### Base Structure
```bash
cd /usr/local/bin/qse-cli-artifacts && ./cli.sh -i [input_path] -l [language] [-cf [class_path]] [-da]
```

| Component | Value | Required |
|---|---|---|
| Change directory | `cd /usr/local/bin/qse-cli-artifacts` | ✅ Yes |
| Command separator | `&&` | ✅ Yes |
| QSE script | `./cli.sh` | ✅ Yes |
| Parameters | `-i [path] -l [ext] [-cf [path]] [-da]` | ✅ Yes (at minimum `-i` and `-l`) |

---

## Parameter Reference

### `-i` — Input Path
The directory containing the source code to scan.

- **Required:** Yes
- **Default:** Current working directory
- **Construction logic:**
  1. Check if user specified a custom path
  2. If not, use current workspace directory
  3. Ensure path is absolute when possible
  4. Verify path exists before constructing command

```bash
-i /Users/shetty/gsi/quantum/qse/crypto-samples
-i /path/to/project
-i .
```

---

### `-l` — Language
File extension indicating the programming language.

- **Required:** Yes
- **Possible values:** `.java`, `.go`, `.dart`, `.py`, `.cpp`
- **Construction logic:**
  1. Detect language using `4_language_detection.md` rules
  2. Map detected language to appropriate extension
  3. If detection fails, ask user to specify

```bash
-l .java
-l .go
-l .py
```

---

### `-cf` — Class File Path
Path to compiled Java class files (bytecode).

- **Required:** Only for Java Cryptographic Analytics scan
- **Default:** Same as input path (`-i`)
- **Construction logic:**
  1. Only include for Java projects with `-da` flag
  2. Search for build output in this order:
     - `target/classes` (Maven)
     - `build/classes/java/main` (Gradle)
     - `out/production` (IntelliJ IDEA)
     - `bin` (Eclipse)
  3. If found, use that path; otherwise use input path as fallback

```bash
-cf /Users/shetty/project/target/classes
-cf /path/to/project/build/classes
-cf /path/to/project    # fallback: same as input path
```

---

### `-da` — Discovery Analytics Flag
Enables Cryptographic Analytics mode.

- **Required:** Only for Cryptographic Analytics scan
- **Include when:** Language is Java AND scan type is Cryptographic Analytics
- **Exclude when:** Scan type is API Discovery OR language is not Java

---

## Construction Algorithms

### Algorithm 1: Java — Cryptographic Analytics

```
1. Start: cd /usr/local/bin/qse-cli-artifacts && ./cli.sh
2. Add: -i [workspace_or_specified_path]
3. Add: -l .java
4. Determine class file path:
     - Search for target/classes, build/classes, out/production, bin
     - If found → use that path
     - If not found → use input path as fallback
5. Add: -cf [determined_path]
6. Add: -da
```

**Example output:**
```bash
cd /usr/local/bin/qse-cli-artifacts && ./cli.sh -i /Users/shetty/project -l .java -cf /Users/shetty/project/target/classes -da
```

---

### Algorithm 2: Java — API Discovery

```
1. Start: cd /usr/local/bin/qse-cli-artifacts && ./cli.sh
2. Add: -i [workspace_or_specified_path]
3. Add: -l .java
4. DO NOT add -cf flag
5. DO NOT add -da flag
```

**Example output:**
```bash
cd /usr/local/bin/qse-cli-artifacts && ./cli.sh -i /Users/shetty/project -l .java
```

---

### Algorithm 3: Non-Java — API Discovery

```
1. Start: cd /usr/local/bin/qse-cli-artifacts && ./cli.sh
2. Add: -i [workspace_or_specified_path]
3. Add: -l [detected_extension]
4. DO NOT add -cf flag (not applicable)
5. DO NOT add -da flag (not applicable)
```

**Example output:**
```bash
cd /usr/local/bin/qse-cli-artifacts && ./cli.sh -i /Users/shetty/project -l .go
```

---

## Common Patterns

### Scan current workspace directory
```bash
cd /usr/local/bin/qse-cli-artifacts && ./cli.sh -i . -l [language]
```

### Scan a user-specified directory
```bash
cd /usr/local/bin/qse-cli-artifacts && ./cli.sh -i [user_path] -l [language]
```

### Java — complete quantum readiness (both scans)
```bash
# Scan 1: Cryptographic Analytics
cd /usr/local/bin/qse-cli-artifacts && ./cli.sh -i [path] -l .java -cf [class_path] -da

# Scan 2: API Discovery
cd /usr/local/bin/qse-cli-artifacts && ./cli.sh -i [path] -l .java
```

---

## Validation Checklist
Before executing any QSE command, verify:

- [ ] Base path is `/usr/local/bin/qse-cli-artifacts`
- [ ] Script name is `./cli.sh`
- [ ] `-i` parameter is present with a valid path
- [ ] `-l` parameter is present with a valid extension
- [ ] For Java Cryptographic Analytics: `-cf` and `-da` are both present
- [ ] For API Discovery: `-da` is **not** present
- [ ] For non-Java: `-cf` is **not** present
- [ ] Command uses `&&` to chain `cd` and execution

---

## Error Prevention Rules
- Never include `-da` for API Discovery scans
- Never include `-cf` for non-Java languages
- Always verify input path exists before executing
- Always use absolute path for QSE installation
- Always include both `-i` and `-l` parameters
- For Java Cryptographic Analytics, always include both `-cf` and `-da`

---

## Path Resolution Notes

**Input path (`-i`):**
1. If user specifies a path → use it as provided
2. If no path specified → use current workspace directory
3. Convert relative paths to absolute when possible
4. Verify path exists before constructing command

**Class file path (`-cf`) for Java:**
1. Use `list_files` to check for build output directories
2. Search in order: `target/classes` → `build/classes` → `out/production` → `bin`
3. If multiple found, prefer Maven (`target`) over Gradle (`build`)
4. If none found, use input path as fallback
5. Always use absolute paths

**Why absolute paths matter:**
> The command changes working directory to `/usr/local/bin/qse-cli-artifacts` before executing, so relative project paths may not resolve correctly.
