# Monitoring and Observability Patterns

Complete implementation patterns for production monitoring and observability.

## Structured Logging Implementation

```python
"""Structured logging with context and correlation IDs."""
import logging
import json
from datetime import datetime
from typing import Dict, Any, Optional
import uuid

class StructuredLogger:
    """Logger with structured output and context."""
    
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
        self.context = {}
    
    def set_context(self, **kwargs):
        """Set context for all subsequent logs."""
        self.context.update(kwargs)
    
    def clear_context(self):
        """Clear logging context."""
        self.context = {}
    
    def _log(self, level: str, message: str, **kwargs):
        """Internal log method with structured output."""
        log_data = {
            "timestamp": datetime.now().isoformat(),
            "level": level,
            "message": message,
            "context": self.context,
            **kwargs
        }
        
        getattr(self.logger, level.lower())(json.dumps(log_data))
    
    def info(self, message: str, **kwargs):
        self._log("INFO", message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        self._log("WARNING", message, **kwargs)
    
    def error(self, message: str, **kwargs):
        self._log("ERROR", message, **kwargs)
    
    def debug(self, message: str, **kwargs):
        self._log("DEBUG", message, **kwargs)

# Usage
logger = StructuredLogger(__name__)
logger.set_context(request_id=str(uuid.uuid4()), user_id="user123")
logger.info("Processing request", endpoint="/api/data")
```

## Request Tracing

```python
"""Distributed tracing with correlation IDs."""
import uuid
from functools import wraps
from flask import request, g

def trace_request(func):
    """Decorator to add tracing to requests."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Get or create correlation ID
        correlation_id = request.headers.get('X-Correlation-ID', str(uuid.uuid4()))
        g.correlation_id = correlation_id
        
        # Log request start
        logger.info(f"Request started: {request.method} {request.path}", extra={
            "correlation_id": correlation_id,
            "method": request.method,
            "path": request.path,
            "remote_addr": request.remote_addr
        })
        
        start_time = time.time()
        
        try:
            result = func(*args, **kwargs)
            duration = time.time() - start_time
            
            # Log request completion
            logger.info(f"Request completed: {request.method} {request.path}", extra={
                "correlation_id": correlation_id,
                "duration_ms": duration * 1000,
                "status": "success"
            })
            
            return result
            
        except Exception as e:
            duration = time.time() - start_time
            
            # Log request failure
            logger.error(f"Request failed: {request.method} {request.path}", extra={
                "correlation_id": correlation_id,
                "duration_ms": duration * 1000,
                "error": str(e),
                "error_type": type(e).__name__
            })
            
            raise
    
    return wrapper
```

## Metrics Collection System

```python
"""Comprehensive metrics collection."""
from collections import defaultdict
from datetime import datetime, timedelta
from threading import Lock
from typing import Dict, List
import statistics

class MetricsCollector:
    """Production-ready metrics collector."""
    
    def __init__(self):
        self.counters = defaultdict(int)
        self.gauges = {}
        self.histograms = defaultdict(list)
        self.timers = {}
        self.lock = Lock()
    
    def increment(self, metric: str, value: int = 1, tags: Dict = None):
        """Increment counter with optional tags."""
        with self.lock:
            key = self._make_key(metric, tags)
            self.counters[key] += value
    
    def set_gauge(self, metric: str, value: float, tags: Dict = None):
        """Set gauge value."""
        with self.lock:
            key = self._make_key(metric, tags)
            self.gauges[key] = value
    
    def record_timing(self, metric: str, duration: float, tags: Dict = None):
        """Record timing measurement."""
        with self.lock:
            key = self._make_key(metric, tags)
            self.histograms[key].append(duration)
            
            # Keep only last 1000 measurements
            if len(self.histograms[key]) > 1000:
                self.histograms[key] = self.histograms[key][-1000:]
    
    def start_timer(self, metric: str, tags: Dict = None):
        """Start timing measurement."""
        key = self._make_key(metric, tags)
        self.timers[key] = time.time()
    
    def stop_timer(self, metric: str, tags: Dict = None):
        """Stop timing and record duration."""
        key = self._make_key(metric, tags)
        if key in self.timers:
            duration = time.time() - self.timers[key]
            self.record_timing(metric, duration, tags)
            del self.timers[key]
    
    def get_metrics(self) -> Dict:
        """Get all metrics with statistics."""
        with self.lock:
            return {
                "timestamp": datetime.now().isoformat(),
                "counters": dict(self.counters),
                "gauges": self.gauges.copy(),
                "histograms": {
                    k: self._calculate_stats(v)
                    for k, v in self.histograms.items()
                }
            }
    
    def _calculate_stats(self, values: List[float]) -> Dict:
        """Calculate statistics for histogram."""
        if not values:
            return {"count": 0}
        
        sorted_values = sorted(values)
        return {
            "count": len(values),
            "min": min(values),
            "max": max(values),
            "mean": statistics.mean(values),
            "median": statistics.median(values),
            "p95": sorted_values[int(len(sorted_values) * 0.95)],
            "p99": sorted_values[int(len(sorted_values) * 0.99)]
        }
    
    def _make_key(self, metric: str, tags: Dict = None) -> str:
        """Create metric key with tags."""
        if not tags:
            return metric
        tag_str = ",".join(f"{k}={v}" for k, v in sorted(tags.items()))
        return f"{metric}[{tag_str}]"

# Global metrics instance
metrics = MetricsCollector()

# Usage
metrics.increment("api.requests", tags={"endpoint": "/api/data", "method": "GET"})
metrics.start_timer("api.duration", tags={"endpoint": "/api/data"})
# ... do work ...
metrics.stop_timer("api.duration", tags={"endpoint": "/api/data"})
```

## Health Check System

```python
"""Comprehensive health check system."""
from typing import Dict, Callable, Tuple
from enum import Enum

class HealthStatus(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"

class HealthChecker:
    """Health check orchestrator."""
    
    def __init__(self):
        self.checks: Dict[str, Callable] = {}
    
    def register_check(self, name: str, check_func: Callable):
        """Register a health check function."""
        self.checks[name] = check_func
    
    def check_all(self) -> Tuple[HealthStatus, Dict]:
        """Run all health checks."""
        results = {}
        overall_status = HealthStatus.HEALTHY
        
        for name, check_func in self.checks.items():
            try:
                status, details = check_func()
                results[name] = {
                    "status": status.value,
                    "details": details
                }
                
                # Update overall status
                if status == HealthStatus.UNHEALTHY:
                    overall_status = HealthStatus.UNHEALTHY
                elif status == HealthStatus.DEGRADED and overall_status == HealthStatus.HEALTHY:
                    overall_status = HealthStatus.DEGRADED
                    
            except Exception as e:
                results[name] = {
                    "status": HealthStatus.UNHEALTHY.value,
                    "error": str(e)
                }
                overall_status = HealthStatus.UNHEALTHY
        
        return overall_status, results

# Example health checks
def check_database() -> Tuple[HealthStatus, Dict]:
    """Check database connectivity."""
    try:
        # Attempt simple query
        result = db.execute("SELECT 1")
        return HealthStatus.HEALTHY, {"latency_ms": 5}
    except Exception as e:
        return HealthStatus.UNHEALTHY, {"error": str(e)}

def check_api() -> Tuple[HealthStatus, Dict]:
    """Check external API connectivity."""
    try:
        response = requests.get(API_URL, timeout=5)
        if response.status_code == 200:
            return HealthStatus.HEALTHY, {"latency_ms": response.elapsed.total_seconds() * 1000}
        else:
            return HealthStatus.DEGRADED, {"status_code": response.status_code}
    except Exception as e:
        return HealthStatus.UNHEALTHY, {"error": str(e)}

def check_cache() -> Tuple[HealthStatus, Dict]:
    """Check cache connectivity."""
    try:
        cache.set("health_check", "ok", ttl=10)
        value = cache.get("health_check")
        if value == "ok":
            return HealthStatus.HEALTHY, {}
        else:
            return HealthStatus.DEGRADED, {"message": "Cache read/write mismatch"}
    except Exception as e:
        return HealthStatus.UNHEALTHY, {"error": str(e)}

# Setup health checker
health_checker = HealthChecker()
health_checker.register_check("database", check_database)
health_checker.register_check("api", check_api)
health_checker.register_check("cache", check_cache)

# Flask endpoint
@app.route('/health')
def health():
    status, results = health_checker.check_all()
    status_code = 200 if status == HealthStatus.HEALTHY else 503
    
    return {
        "status": status.value,
        "timestamp": datetime.now().isoformat(),
        "checks": results
    }, status_code
```

## Performance Monitoring

```python
"""Performance monitoring decorator."""
import time
from functools import wraps

def monitor_performance(metric_name: str = None):
    """Decorator to monitor function performance."""
    def decorator(func):
        name = metric_name or f"{func.__module__}.{func.__name__}"
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time
                
                # Record success metrics
                metrics.increment(f"{name}.calls")
                metrics.record_timing(f"{name}.duration", duration)
                
                # Log slow operations
                if duration > 1.0:
                    logger.warning(f"Slow operation: {name} took {duration:.2f}s")
                
                return result
                
            except Exception as e:
                duration = time.time() - start_time
                
                # Record error metrics
                metrics.increment(f"{name}.errors", tags={"error_type": type(e).__name__})
                metrics.record_timing(f"{name}.duration", duration)
                
                raise
        
        return wrapper
    return decorator

# Usage
@monitor_performance("api.fetch_data")
def fetch_data(endpoint):
    return api_client.get(endpoint)