# Concert API Reference

Complete reference for IBM Concert API endpoints with resilience patterns.

## Authentication Headers (CRITICAL)

All Concert API requests MUST include these headers:

```python
headers = {
    "Accept": "application/json",              # Required
    "Authorization": f"C_API_KEY {api_key}",   # Required - proper capitalization
    "InstanceID": instance_id,                 # Required - UUID format
    "Content-Type": "application/json"         # Required
}
```

**Common Errors:**
- Missing Accept header → content negotiation issues
- Lowercase "authorization" → may fail with proxies
- Missing InstanceID → 400 Bad Request
- Wrong auth type → Use `C_API_KEY` for SaaS/VM, `ZenAPIKey` for OCP

## Base Configuration

```python
BASE_URL = "https://91431.us-south-8.concert.saas.ibm.com"
TIMEOUT = (5, 30)  # connect, read
MAX_RETRIES = 3
```

## Application Endpoints

### GET /core/api/v1/applications
List all applications with pagination.

**Response Structure:**
```json
{
  "pagination": {
    "total_count": 20,
    "total_pages": 1,
    "page_size": 100,
    "page_number": 1
  },
  "applications": [...]
}
```

**Key Fields:**
- `id`, `name`, `version`, `latest`
- `criticality`, `data_impact_risk` (may be int or string!)
- `business_units`, `tags`, `properties`
- `last_updated_on`, `last_updated_by`

**Type Safety Warning:**
```python
# WRONG - may fail if criticality is int
if app.get("criticality").lower() == "critical":

# CORRECT - handles both int and string
if str(app.get("criticality", "")).lower() == "critical":
```

**Caching:** 5 minutes (300s)

### GET /core/api/v1/applications/{id}
Get detailed application information.

**Response:** Single application object (no wrapper)

**Caching:** 10 minutes (600s)

### GET /core/api/v1/applications/{id}/vulnerability_details
Get vulnerability details for specific application.

**Response Structure:**
```json
{
  "vulnerability_details": [
    {
      "cve": "CVE-2024-1234",
      "highest_finding_risk_score": 9.8,
      "priority_findings": {...}
    }
  ]
}
```

**Caching:** 30 minutes (1800s)

### GET /core/api/v1/applications/{id}/build_artifacts
Get build artifacts for application.

**Response Structure:**
```json
{
  "pagination": {...},
  "build_artifacts": [
    {
      "id": "artifact-uuid",
      "name": "artifact-name",
      "image_tag": "v1.0.0",
      "last_updated_on": 1711234567  // SECONDS, not milliseconds!
    }
  ]
}
```

**Date Handling (CRITICAL):**
```python
# API returns timestamp in SECONDS
timestamp = artifact.get("last_updated_on")
dt = datetime.fromtimestamp(timestamp)  # Do NOT divide by 1000
formatted = dt.strftime("%a %b %d %H:%M:%S %Y")
```

**Caching:** 20 minutes (1200s)

### GET /core/api/v1/applications/{id}/build_artifacts/{artifact_id}/cves
Get CVEs for specific build artifact.

**Response Structure:**
```json
{
  "cves": [
    {
      "cve": "CVE-2024-1234",
      "highest_finding_risk_score": 9.8,
      "highest_finding_priority": 1,  // May be int or string!
      "cvss": 9.8,
      "total_findings": 5
    }
  ]
}
```

**Priority Handling:**
```python
priority = cve.get("highest_finding_priority", "N/A")
if priority != "N/A" and priority is not None:
    if isinstance(priority, str):
        priority = int(priority)
    # Now safe to compare as int
```

**Caching:** 30 minutes (1800s)

## Package Endpoints

### GET /core/api/v1/software_composition/packages
List all software packages.

**Response Structure:**
```json
{
  "packages": [
    {
      "id": "pkg-uuid",
      "name": "package-name",
      "version": "1.0.0",
      "avg_score": 5.31,  // NOT "risk_score"!
      "licenses": [       // Array of objects!
        {"id": "MIT", "status": "allowed"}
      ],
      "vulnerability_count": 0
    }
  ]
}
```

**Critical Field Mappings:**
- Risk Score → `avg_score` (NOT "risk_score")
- License → Extract from `licenses` array

**License Extraction:**
```python
licenses = pkg.get("licenses", [])
if licenses and isinstance(licenses, list):
    license_ids = [
        str(lic.get("id")) 
        for lic in licenses
        if isinstance(lic, dict) and lic.get("id")
    ]
    license_info = ", ".join(license_ids) if license_ids else "N/A"
```

**Caching:** 10 minutes (600s)

### GET /core/api/v1/software_composition/recommendations
Get package upgrade recommendations.

**Response Structure:**
```json
{
  "recommendations": [
    {
      "id": "rec-uuid",
      "package_name": "debug",
      "package_version": "3.2.7",
      "risk_type": "Lower Version",
      "action": "Upgrade to version latest",
      "description": "A newer version is available",  // Actually justification!
      "justification": "Upgrade to version: 4.4.3"    // Actually description!
    }
  ]
}
```

**Field Swap Warning (CRITICAL):**
The API fields are counterintuitive:
- API `description` → UI Justification (reason)
- API `justification` → UI Description (action details)

**Caching:** 15 minutes (900s)

## Certificate Endpoints

### GET /core/api/v1/certificates
List all SSL/TLS certificates.

**Response Structure:**
```json
{
  "pagination": {...},
  "certificates": [
    {
      "id": "cert-uuid",
      "subject": "CN=example.com",
      "validity_end_date": 1711234567000,  // May be int or string!
      "environment": {                      // Object, not string!
        "id": "env-uuid",
        "name": "Production"
      }
    }
  ]
}
```

**Date Handling:**
```python
expiry = cert.get("validity_end_date")
if isinstance(expiry, int):
    # Timestamp in milliseconds
    dt = datetime.fromtimestamp(expiry / 1000)
    expiry_str = dt.strftime("%Y-%m-%d")
elif isinstance(expiry, str) and len(expiry) > 10:
    # ISO string
    expiry_str = expiry[:10]
```

**Caching:** 1 hour (3600s)

## Error Handling Strategy

```python
def handle_concert_api_error(response, endpoint):
    """Handle Concert API errors appropriately."""
    status = response.status_code
    
    if 400 <= status < 500:
        # Client error - don't retry
        logger.error(f"Client error {status} for {endpoint}")
        return None
    
    elif 500 <= status < 600:
        # Server error - retry with backoff
        logger.warning(f"Server error {status} for {endpoint}, will retry")
        raise RetryableError(f"Server error: {status}")
    
    elif status == 429:
        # Rate limited - wait and retry
        logger.warning(f"Rate limited on {endpoint}")
        raise RateLimitError("Too many requests")
```

## Resilience Checklist

- [ ] All 4 required headers included
- [ ] Proper header capitalization
- [ ] Connection pooling configured
- [ ] Timeouts set (5s connect, 30s read)
- [ ] Retry logic with exponential backoff
- [ ] Rate limiting implemented
- [ ] Type checking before operations
- [ ] Caching with appropriate TTL
- [ ] Comprehensive error handling
- [ ] Logging for all requests
- [ ] Fallback to cached data on failure