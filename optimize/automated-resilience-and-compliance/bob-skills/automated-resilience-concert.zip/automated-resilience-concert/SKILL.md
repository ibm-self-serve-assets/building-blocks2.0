---
name: automate-resilience
description: Build resilient, secure, and observable systems with API integration patterns, comprehensive monitoring, and security automation for Concert API and production applications
---

Use this skill when working on:

**API Integration & Resilience:**
- Building resilient Concert API integrations with retry logic
- Implementing circuit breakers and bulkhead patterns
- Creating API health monitoring and alerting systems
- Optimizing API request patterns and batching
- Implementing rate limiting and throttling mechanisms
- Building API response caching strategies
- Creating fallback mechanisms for API failures

**Monitoring & Observability:**
- Implementing comprehensive logging systems
- Building metrics collection and visualization
- Creating real-time alerting and notification systems
- Developing health check endpoints and monitoring
- Implementing distributed tracing for request flows
- Building performance monitoring dashboards
- Creating SLA/SLO tracking and reporting

**Security & Automation:**
- Automating security scanning and vulnerability tracking workflows
- Building risk scoring and prioritization systems
- Creating automated security assessment pipelines
- Implementing vulnerability remediation automation
- Developing security compliance checking and reporting
- Building automated threat detection systems
- Implementing secure credential management systems

---

## Workflow

<Steps>
<Step>
**Understand the Requirement**
- Identify the primary objective (API integration, monitoring, security, etc.)
- Determine the scope (single component, system-wide, infrastructure)
- Assess criticality and priority level
- Identify dependencies and integration points
</Step>

<Step>
**Gather Context**
- Use `list_files` to understand project structure
- Use `read_file` to examine existing implementations
- Use `search_files` to find related code patterns
- Use `list_code_definition_names` to identify key components
- Review existing error handling, monitoring, and security patterns
</Step>

<Step>
**Design Resilient Solution**
- Identify failure points and edge cases
- Design error handling strategy with retry logic and exponential backoff
- Plan monitoring and observability (metrics, logs, alerts)
- Design caching strategy with appropriate TTLs
- Plan security measures (credential management, audit logging)
</Step>

<Step>
**Implement Core Features**

**For API Integration:**
- Setup API client with connection pooling
- Configure authentication headers (Accept, Authorization, InstanceID, Content-Type)
- Implement retry logic with exponential backoff (1s, 2s, 4s, 8s, 16s)
- Add rate limiting with token bucket algorithm
- Implement comprehensive error handling by status code
- Add type-safe data handling for API responses
- Implement caching with appropriate TTLs

**For Monitoring:**
- Setup structured logging with context and correlation IDs
- Implement metrics collection (counters, gauges, histograms)
- Create health check endpoints (liveness and readiness)
- Build monitoring dashboards for key metrics
- Configure alerting with severity levels
- Add distributed tracing support

**For Security:**
- Implement secure credential management (environment variables, vaults)
- Build vulnerability scanning automation
- Implement risk scoring with CVSS and context
- Create compliance automation workflows
- Add certificate expiration monitoring
- Implement security audit logging
</Step>

<Step>
**Test and Validate**
- Test error scenarios (network failures, timeouts, rate limiting)
- Verify monitoring (logs, metrics, alerts, health checks)
- Perform security testing (credential validation, vulnerability scanning)
- Conduct performance testing (load, stress, cache effectiveness)
- Validate resilience patterns (retry, circuit breaker, fallback)
</Step>

<Step>
**Document Implementation**
- Add code comments and docstrings
- Update README with new features
- Create runbooks for common issues
- Document architecture and data flows
- Create alert response playbooks
</Step>
</Steps>

---

## API Resilience Patterns

### Resilient API Client Setup
```python
import requests
from typing import Optional, Dict, Any

class ResilientAPIClient:
    """API client with comprehensive resilience features."""
    
    def __init__(self, base_url: str, api_key: str, instance_id: str):
        self.base_url = base_url
        self.session = requests.Session()
        
        # Configure required headers for Concert API
        self.session.headers.update({
            "Accept": "application/json",
            "Authorization": f"C_API_KEY {api_key}",
            "InstanceID": instance_id,
            "Content-Type": "application/json"
        })
    
    def make_request(self, endpoint: str, max_retries: int = 3, **kwargs):
        """Make resilient API request with retry logic."""
        url = f"{self.base_url}{endpoint}"
        
        for attempt in range(max_retries):
            try:
                response = self.session.get(url, timeout=(5, 30), **kwargs)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                if attempt == max_retries - 1:
                    logger.error(f"Failed after {max_retries} attempts: {e}")
                    return None
                wait_time = 2 ** attempt
                time.sleep(wait_time)
        return None
```

### Type-Safe Data Handling
```python
def safe_string_operation(value: Any) -> str:
    """Safely convert to string before operations."""
    return str(value).lower() if value else ""

def safe_date_parsing(date_value: Any) -> Optional[datetime]:
    """Parse date handling multiple formats."""
    if isinstance(date_value, int):
        if date_value > 10000000000:
            return datetime.fromtimestamp(date_value / 1000)
        return datetime.fromtimestamp(date_value)
    elif isinstance(date_value, str):
        try:
            return datetime.fromisoformat(date_value.replace('Z', '+00:00'))
        except ValueError:
            return None
    return None
```

---

## Monitoring Patterns

### Structured Logging
```python
import logging
import json
from datetime import datetime

class StructuredLogger:
    """Logger with structured output and context."""
    
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
        self.context = {}
    
    def set_context(self, **kwargs):
        """Set context for all subsequent logs."""
        self.context.update(kwargs)
    
    def info(self, message: str, **kwargs):
        """Log info with context."""
        log_data = {
            "timestamp": datetime.now().isoformat(),
            "level": "INFO",
            "message": message,
            "context": self.context,
            **kwargs
        }
        self.logger.info(json.dumps(log_data))
```

### Health Check Endpoints
```python
@app.route('/health')
def health_check():
    """Basic health check endpoint."""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat()
    }, 200

@app.route('/health/ready')
def readiness_check():
    """Readiness check with dependencies."""
    checks = {
        "database": check_database(),
        "api": check_api_connection(),
        "cache": check_cache()
    }
    all_healthy = all(checks.values())
    return {
        "status": "ready" if all_healthy else "not_ready",
        "checks": checks
    }, 200 if all_healthy else 503
```

---

## Security Patterns

### Secure Credential Management
```python
import os
from dotenv import load_dotenv

class SecureConfig:
    """Secure configuration management."""
    
    def __init__(self):
        load_dotenv()
        self.api_key = self._get_required("CONCERT_API_KEY")
        self.instance_id = self._get_required("CONCERT_INSTANCE_ID")
        self.base_url = self._get_required("CONCERT_BASE_URL")
    
    def _get_required(self, key: str) -> str:
        """Get required environment variable."""
        value = os.getenv(key)
        if not value:
            raise ValueError(f"Required environment variable {key} not set")
        return value
    
    def validate(self):
        """Validate configuration."""
        if not self.base_url.startswith("https://"):
            raise ValueError("Base URL must use HTTPS")
        logger.info("Configuration validated successfully")
```

### Vulnerability Risk Scoring
```python
def calculate_risk_score(vulnerability: Dict) -> float:
    """Calculate comprehensive risk score."""
    cvss = vulnerability.get("cvss", 0)
    
    exploitability = {
        "high": 2.0,
        "medium": 1.5,
        "low": 1.0
    }.get(vulnerability.get("exploitability", "low"), 1.0)
    
    criticality = {
        "critical": 2.0,
        "high": 1.5,
        "medium": 1.0,
        "low": 0.5
    }.get(vulnerability.get("asset_criticality", "medium"), 1.0)
    
    risk_score = cvss * exploitability * criticality / 2
    return min(risk_score, 10.0)
```

---

## Critical Requirements

### Concert API Headers (MUST INCLUDE)
All Concert API requests MUST include these headers:
- `Accept: application/json`
- `Authorization: C_API_KEY {api_key}` (proper capitalization!)
- `InstanceID: {instance_id}` (UUID format)
- `Content-Type: application/json`

### Type Safety
Always validate data types before operations:
- Use `str(value).lower()` instead of `value.lower()`
- Check `isinstance(date, int)` before parsing timestamps
- Use `.get()` with defaults instead of direct dictionary access
- Wrap parsing operations in try-except blocks

### Error Handling Strategy
- 400-499: Client errors - log and alert, don't retry
- 500-599: Server errors - retry with exponential backoff
- 429: Rate limited - wait and retry
- Network errors: Retry up to 3 times with backoff

### Caching Strategy
Set TTL based on data volatility:
- Real-time data: 1-5 minutes
- Semi-static data: 15-30 minutes
- Static data: 1-4 hours

---

## Supporting Files

Refer to these files for detailed implementations:
- `api-resilience/api-patterns.md` - Complete API patterns
- `api-resilience/concert-api-reference.md` - Concert API reference
- `monitoring-observability/monitoring-patterns.md` - Monitoring implementations
- `security-automation/security-checklist.md` - Security requirements

---

## Best Practices

1. **Always read files before modifying** - Use `read_file` to get exact content
2. **Use type-safe operations** - Validate types before string/date operations
3. **Implement comprehensive logging** - Log at key decision points
4. **Add retry logic** - Use exponential backoff for transient failures
5. **Monitor everything** - Metrics, logs, alerts, health checks
6. **Secure credentials** - Never hardcode, use environment variables
7. **Test error scenarios** - Network failures, timeouts, rate limiting
8. **Document thoroughly** - Code comments, runbooks, architecture docs