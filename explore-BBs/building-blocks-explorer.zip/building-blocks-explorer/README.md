# 🧱 IBM Building Blocks Explorer

A Bob mode that takes you from a business use case to a build-ready
workspace. Describe what you (or your client) want to build — the Explorer
finds the right IBM Technology Building Blocks, designs a solution with you,
and installs the matching **Bob skills** and **Bob modes** into this
workspace so you can start building immediately.

## Prerequisites

- **Bob** (this mode runs inside it)
- **[uv](https://docs.astral.sh/uv/)** — used to run the local install
  helper. One-line install, no admin rights, any OS:
  `curl -LsSf https://astral.sh/uv/install.sh | sh` (or `brew install uv`)
- Internet access to `github.com` and the Building Blocks catalog service

Nothing else — no Python, no git, no Node required.

## Install

1. Unzip this archive.
2. Open the resulting `building-blocks-explorer/` folder as your workspace
   in Bob (the configuration lives in the hidden `.bob/` folder).
3. Select **🧱 IBM Building Blocks Explorer** from Bob's mode picker.

## Try it

- *"I'm meeting an insurance client about a claims assistant — it needs to
  answer from their policy documents and be safe for production."*
- *"What skills are there for Terraform?"*
- *"Install the agent-ops skill for me."*

The Explorer interviews you briefly (one question at a time), designs the
solution, shows an architecture diagram, and — with your approval — installs
the recommended skills into `.bob/skills/` and merges any recommended
builder mode into this workspace. Reload Bob afterward and everything is
active side by side.

## How it works

The mode connects to two MCP servers (configured automatically in
`.bob/mcp.json`):

- **building-blocks** — the remote catalog: blocks, skills, modes, docs
- **building-blocks-installer** — a small local helper that performs the
  installs. It is deliberately scoped: it only downloads from the official
  Building Blocks repository and only writes inside this workspace.

## Troubleshooting

- **"Catalog tools unavailable"** — check Bob's MCP panel: the
  `building-blocks` server should show Connected. If not, reload Bob
  (fully quit and reopen); check your network can reach the catalog URL in
  `.bob/mcp.json`.
- **Installer unavailable** — usually means `uv` is missing; install it
  (see Prerequisites) and reload Bob. Until then the Explorer will guide
  you through a manual install instead.
- **First launch is slow** — the install helper is fetched and cached on
  first use; later launches are instant.

## What gets written where

Installs touch only this workspace: skills land in `.bob/skills/<name>/`,
modes merge into `.bob/`, and design artifacts (`use_case_summary.md`,
`architecture_diagram.png`) are written at the workspace root.
